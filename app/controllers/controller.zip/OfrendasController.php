<?php
/** 
*
* @Redil Software. OfrendaController.php 
* @versión: 1.0.0     @modificado: 24 de Abril del 2015
* @autor última modificación: Felipe Fajardo 
* 
*/
class OfrendasController extends BaseController
{
	public function __construct()
	{
		
		$this->beforeFilter('auth');  //bloqueo de acceso
		
	}

	//lista financiera
	public function getIndex()
	{
		return Redirect::to('ofrendas/lista/todos');
	}

	public function getLista($tipo="todos")
	{	

		$valor="";
		$listar_tipo_ingreso=false;
		$fecha_actual=new DateTime();
		$ano = $fecha_actual->format('Y');
		$ano.= "-01-01";

		$mes = $fecha_actual->format('Y-m');
		$mes.= "-01";

		if($tipo=="por-reunion")
		{
			$valor=0;
			$listar_tipo_ingreso=true;
		}
		else if ($tipo=="por-grupo")
		{	
			$valor=1;
			$listar_tipo_ingreso=true;
		}
		else if ($tipo=="otros")
		{	
			$valor=2;
			$listar_tipo_ingreso=true;
		}


		if (isset($_GET["buscar"]))
		{    
			$cantidad_busqueda=0;
			$buscar= htmlspecialchars(Input::get('buscar'));
			$buscar_array=explode(" ", $buscar);
			Global $sql_buscar;
			$c=0;

			foreach($buscar_array as $palabra)
			{
				if($c!=0)
				  $sql_buscar.=" AND ";

				  $sql_buscar.="(asistentes.nombre ILIKE '%$palabra%' OR asistentes.apellido ILIKE '%$palabra%'";
					if(ctype_digit($palabra))
						$sql_buscar.=" OR ofrendas.asistente_id=$palabra OR ofrendas.valor=$palabra";

					$portipo=false;

					if($palabra=="diezmo" || $palabra=="diezmos")
					{
						$palabra=0;
						$portipo=true;
					}
					else if ($palabra=="ofrenda" || $palabra=="ofrendas")
					{	
						$palabra=1;
						$portipo=true;
					}
					else if ($palabra=="pacto" || $palabra=="pactos")
					{	
						$palabra=2;
						$portipo=true;
					}
					else if ($palabra=="pro-templo" || $palabra=="protemplo")
					{	
						$palabra=3;
						$portipo=true;
					}
					else if ($palabra=="siembra" || $palabra=="siembras")
					{	
						$palabra=4;
						$portipo=true;
					}
					else if ($palabra=="primicia" || $palabra=="primicias")
					{	
						$palabra=5;
						$portipo=true;
					}
					else if ($palabra=="suelta" || $palabra=="sueltas")
					{	
						$palabra=7;
						$portipo=true;
					}

					if($portipo)
						$sql_buscar.=" OR ofrendas.tipo_ofrenda=$palabra";
					$sql_buscar.=")";
                    $c++;
				}//foreach
			

			if(Auth::user()->id==1)
			{			

			//Busqueda especial  sin separar la frase por palabras.
			if ($buscar=="ofrenda suelta" || $buscar=="ofrendas sueltas")
			{
				$sql_buscar="(ofrendas.tipo_ofrenda=7)";
			}

				if($tipo=="todos")
				{
					$ofrendas=  Ofrenda::leftJoin('asistentes', 'ofrendas.asistente_id', '=', 'asistentes.id')
					->where(function($query)
					{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			            	$query->whereRaw($sql_buscar_l);
			            })
					->get(array('ofrendas.id'));
				}
				else if($listar_tipo_ingreso)
				{

					$ofrendas=  Ofrenda::leftJoin('asistentes', 'ofrendas.asistente_id', '=', 'asistentes.id')
					->where(function($query)
					{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			            	$query->whereRaw($sql_buscar_l);
			            })
					->where('ofrendas.ingresada_por', '=', '"$valor"')
					->get(array('ofrendas.id'));
				}
				else if($tipo=="mes")
				{

					$ofrendas=  Ofrenda::leftJoin('asistentes', 'ofrendas.asistente_id', '=', 'asistentes.id')
					->where(function($query)
					{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			            	$query->whereRaw($sql_buscar_l);
			            })
					->where('ofrendas.fecha', '>', "$mes")
					->get(array('ofrendas.id'));
				}
			    else if($tipo=="año")
				{
					$ofrendas=  Ofrenda::leftJoin('asistentes', 'ofrendas.asistente_id', '=', 'asistentes.id')
					->where(function($query)
					{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			            	$query->whereRaw($sql_buscar_l);
			            })
					->where('ofrendas.fecha', '>', "$ano")
					->get(array('ofrendas.id'));
				}

				$ofrendas_ids_fin=array();
				foreach ($ofrendas as $ofrenda) {
					array_push($ofrendas_ids_fin, $ofrenda->id);
				}

				$ofrendas=Ofrenda::whereIn('ofrendas.id', $ofrendas_ids_fin)
				->orderBy('id', 'asc')
			
				->paginate(10);

				$cantidad_busqueda=Ofrenda::whereIn('ofrendas.id', $ofrendas_ids_fin)->count();
			}
			else
			{
				//este es para saber las ofrendas de los discipulos que tiene directamente el usuario logueado
				$sql2="";
				$grupos=Auth::user()->asistente->grupos()->get();
				$c=0;
				foreach ($grupos as $grupo) 
				{
					if($c!=0)
						$sql2.=" OR ";
					$sql2.="branch LIKE '%,".$grupo->id.",%'";
					$c++;
				}

				//este es para conocer todos los grupos indirectos del usuario logueado
				$grupos_ids= array();
				$grupos=Grupo::whereRaw($sql2)->where('dado_baja', '!=', '1')->get(array('grupos.id'));

				foreach ($grupos as $grupo) {
					array_push($grupos_ids, $grupo->id);
				}

                $asistentes_todos = Asistente::whereIn('grupo_id', $grupos_ids)->get(array('asistentes.id'));

                //Carga en un arreglo los ids de todos los asistentes que pertenecen al usuario autenticado
				$asistentes_ids= array();
				foreach ($asistentes_todos as $asistente) {
					array_push($asistentes_ids, $asistente->id);
				}

                //Carga ademas el id del usuario autenticado
				$usuario_id=Auth::user()->asistente->id;
				array_push($asistentes_ids, $usuario_id);

				if($tipo=="todos")
				{
					$ofrendas=  Ofrenda::leftJoin('asistentes', 'ofrendas.asistente_id', '=', 'asistentes.id')
					->where(function($query)
					{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			            	$query->whereRaw($sql_buscar_l);
			            })
					->whereIn('ofrendas.asistente_id', $asistentes_ids)
					->get(array('ofrendas.id'));
				}
				else if($listar_tipo_ingreso)
				{
					$ofrendas=  Ofrenda::leftJoin('asistentes', 'ofrendas.asistente_id', '=', 'asistentes.id')
					->where(function($query)
					{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			            	$query->whereRaw($sql_buscar_l);
			            })
					->where('ofrendas.ingresada_por', '=', '"$valor"')
					->whereIn('ofrendas.asistente_id', $asistentes_ids)
					->get(array('ofrendas.id'));
				}
                else if($tipo=="mes")
				{

					$ofrendas=  Ofrenda::leftJoin('asistentes', 'ofrendas.asistente_id', '=', 'asistentes.id')
					->where(function($query)
					{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			            	$query->whereRaw($sql_buscar_l);
			            })
					->where('ofrendas.fecha', '>', "$mes")
					->get(array('ofrendas.id'));
				}
			    else if($tipo=="año")
				{

					$ofrendas=  Ofrenda::leftJoin('asistentes', 'ofrendas.asistente_id', '=', 'asistentes.id')
					->where(function($query)
					{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			            	$query->whereRaw($sql_buscar_l);
			            })
					->where('ofrendas.fecha', '>', "$ano")
					->get(array('ofrendas.id'));
				}
				$ofrendas_ids_fin=array();
				foreach ($ofrendas as $ofrenda) {
					array_push($ofrendas_ids_fin, $ofrenda->id);
				}

				$ofrendas=Ofrenda::whereIn('ofrendas.id', $ofrendas_ids_fin)
				->orderBy('id', 'asc')
			
				->paginate(10);

				$cantidad_busqueda=Ofrenda::whereIn('ofrendas.id', $ofrendas_ids_fin)->count();

			  }
			  return View::make('ofrendas.index')-> with(
				array(
					'ofrendas' => $ofrendas, 
					'tipo' => $tipo,
					'buscar' => $buscar,
					'cantidad_busqueda' => $cantidad_busqueda,
					));
			}
			else 
			{
				if(Auth::user()->id==1)
				{

					if($tipo=="todos")
					{
						$ofrendas=  Ofrenda::orderBy('id', 'asc')
					
						->paginate(10);
					}
					else if($listar_tipo_ingreso)
					{
						 $ofrendas= Ofrenda::where("ofrendas.ingresada_por", '=', "$valor")
						->orderBy('id', 'asc')
					
						->paginate(10);
					}
					else if($tipo=="mes")
				{
						$ofrendas=  Ofrenda::where('ofrendas.fecha', '>', "$mes")
						->orderBy('id', 'asc')
					
						->paginate(10);
					
				}
			    else if($tipo=="año")
				{
						$ofrendas=  Ofrenda::where('ofrendas.fecha', '>', "$ano")
						->orderBy('id', 'asc')
					
						->paginate(10);
				}

				}
				else
				{

				//este es para saber los grupos que tiene directamente el usuario logueado
					$sql2="";
					$grupos=Auth::user()->asistente->grupos()->get();
					$c=0;
					foreach ($grupos as $grupo) 
					{
						if($c!=0)
							$sql2.=" OR ";
						$sql2.="branch LIKE '%,".$grupo->id.",%'";
						$c++;
					}

				//este es para conocer todos los grupos indirectos del usuario logueado
					$grupos_ids= array();
					$grupos=Grupo::whereRaw($sql2)->where('dado_baja', '!=', '1')->get(array('grupos.id'));

					foreach ($grupos as $grupo) {
						array_push($grupos_ids, $grupo->id);
					}
                    
                    //Carga en un arreglo los ids de todos los asistentes que pertenecen al usuario autenticado
					$asistentes_todos = Asistente::whereIn('grupo_id', $grupos_ids)->get(array('asistentes.id'));
					$asistentes_ids= array();

					foreach ($asistentes_todos as $asistente) {
						array_push($asistentes_ids, $asistente->id);
					}

					//Carga ademas el id del usuario autenticado
					$usuario_id=Auth::user()->asistente->id;
					array_push($asistentes_ids, $usuario_id);

                    //Carga las ofrendas del usuario autenticado y sus asistentes
					$ofrendas= Ofrenda::whereIn('asistente_id', $asistentes_ids);

					if($tipo=="todos")
					{
						$ofrendas= $ofrendas->orderBy('id', 'asc')
					
						->paginate(10);
					}
					else if($listar_tipo_ingreso)
					{
						$ofrendas= $ofrendas->where("ingresada_por", '=', "$valor")
						->orderBy('id', 'asc')
					
						->paginate(10);
					}
					else if($tipo=="mes")
					{
						$ofrendas= $ofrendas->where('ofrendas.fecha', '>', "$mes")
						->orderBy('id', 'asc')
						->paginate(10);
					
					}
			   		 else if($tipo=="año")
					{

						$ofrendas= $ofrendas->where('ofrendas.fecha', '>', "$ano")
						->orderBy('id', 'asc')
					
						->paginate(10);
					}

					}
				return View::make('ofrendas.index')-> with(
					array(
						'ofrendas' => $ofrendas, 
						'tipo' => $tipo,
						));
			}
		}

		public function getNuevo()
		{
			//$asistentes = Asistente::where('dado_baja', '=', '0')
			$asistentes = Asistente::orderBy('id', 'asc')
						->take(10)
						->get();

			return  View::make('ofrendas.nuevo')->with('asistentes', $asistentes);
		}


		public function postNew ()
		{
			$ofrenda= new Ofrenda;
			$ofrenda->tipo_ofrenda= Input::get ('tipo_ofrenda');
			$ofrenda->valor= Input::get ('valor');
			$ofrenda->fecha= Input::get ('fecha');
		$ofrenda->ingresada_por=2; // Por defecto es 2(otros) ya que el ingreso de este formulario no es de culto ni de grupo
		$ofrenda->observacion= Input::get ('observacion');
		$ofrenda->asistente_id=Input::get('asistente_id');; //Usuario al que sera asignado el ingreso (Ingreso no de grupo ni de reunion) 
		
		$ofrenda->save();

			//return Redirect::to('users')->with('status', 'ok_update');
		return Redirect::to('ofrendas/nuevo')->with (array(
			'status'  => 'ok_update',
			'ofrenda'=>$ofrenda->valor,
			'ofrenda_id'=>$ofrenda->id,
			));

		}


	public function getInforme($id)
	{
		$ofrenda = Ofrenda::find($id);
		if(!isset($ofrenda)) return App::abort(404);

		return View::make('ofrendas.informe')->with(
			array('ofrenda' => $ofrenda));;
	}

	public function getActualizar($id)
	{
		$ofrenda = Ofrenda::find($id);
			return View::make('ofrendas.actualizar')->with(
				array('ofrenda' => $ofrenda));
	}

    public function getEliminar($id)
	{
          $ofrenda= Ofrenda::find($id);
          $ofrenda->delete();
          return Redirect::to('ofrendas/lista/todos')->with (array(
          	'status'  => 'ok_delete',
            'ofrenda_id_eliminada'=>$id,
            ));
	}


	public function getInformepdf($id)
	{
		$ofrenda=Ofrenda::find($id);
		$html=View::make('ofrendas.pdf.informe_pdf')-> with(
			array('ofrenda' => $ofrenda));
	    return PDF::load(utf8_decode($html), 'letter', 'portrait')->show();	

	}

	public function postUpdate($id)
	{
		$ofrenda= Ofrenda::find($id);
		$fecha=date("Y-m-d", strtotime(str_replace('/', '-',Input::get ('fecha'))) );
		$ofrenda->fecha= $fecha;
		$ofrenda->tipo_ofrenda= Input::get ('tipo_ofrenda');
		$ofrenda->valor= Input::get ('valor');
		$ofrenda->observacion= Input::get ('observacion');
        $ofrenda->save();

        return Redirect::to('ofrendas/actualizar/'.$id)->with (array('status'  => 'ok_update'));
	}



/////////////////////////esta es la parte de la busqueda tipo FACEBOOK de asistentes/////////////////////////////////////////////////////////
	//Metodo ajax: LineaSeleccionada
	//  Recibe como parámetro un el id de la línea que se seleccione. 
	//  Retrona un de forma grafica el nombre de la linea, el codigo y los encargado(s)

	public function postAsistenteSeleccionado($id) 
	{
		$asistente=Asistente::find($id);
		$respuesta='<div id="ico-asistente" class="col-xs-3 col-md-3 col-lg-3 bg-blue" style="min-height: 106px; box-shadow: 0 1px 1px rgba(0,0,0,0.1); ">';
        $respuesta.=   '<center><i class="fa fa fa-share-alt fa-4x" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"></i></center>';
        $respuesta.='</div>';
        $respuesta.='<div id="info-asistente" class="col-xs-9 col-md-9 col-lg-9 " style="min-height: 106px;box-shadow: 0 1px 1px 0 rgba(0,0,0,0.1);">';
		$respuesta.='<h4><b>Asistente </b>'.$asistente->id.' - '.$asistente->nombre.'</h4>';
		$respuesta.='<p><b>Linea: </b>'.$asistente->grupo->linea->nombre.'<br>';
		          if ($asistente->tipo_asistente_id==5)
		          {
		          	$respuesta.='<label class="label arrowed-right bg-purple" data-toggle="tooltip" data-placement="top" title="'.$asistente->tipoAsistente->nombre.'"><i class="fa fa-book" style="margin-right:15 px;"> </i></label>';
		          }elseif($asistente->tipo_asistente_id==4)
		          {
		          	$respuesta.='<label class="label arrowed-right bg-orange" data-toggle="tooltip" data-placement="top" title="'.$asistente->tipoAsistente->nombre['nombre'].'"><i class="fa fa-star" style="margin-right:15 px;"> </i></label>';
		          }
		            
		           $respuesta.=' '.$asistente->tipoAsistente->nombre.'<br>';
		        
		$respuesta.='</p></div>';
		return $respuesta;
	}

	////////// este es el ajax que devuelve las siguientes 10 grupos para el panel de grupos 
	public function postObtieneAsistentesAjax($cant_asistentes_cargados, $buscar="")
	{
		$cant_asistentes=0;
		if($buscar=="")
		{			
			//$asistentes= Asistente::where("dado_baja", "0")
			$asistentes= Asistente::orderBy("id", 'asc')
		        ->skip($cant_asistentes_cargados)
		        ->take(10)
		        ->get();

		}else
		{
            $buscar= htmlspecialchars($buscar);
			$buscar_array=explode(" ", $buscar);
			Global $sql_buscar;
			$c=0;
			foreach($buscar_array as $palabra)
			{
				if($c!=0)
					$sql_buscar.=" AND ";
				$sql_buscar.="(asistentes.nombre ILIKE '%$palabra%' OR asistentes.apellido ILIKE '%$palabra%'";
				if(ctype_digit($palabra))
					$sql_buscar.=" OR asistentes.id=$palabra";
				$sql_buscar.=")";
				$c++;
			}


			$asistentes = Asistente::where(function($query)
						{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			                $query->whereRaw($sql_buscar_l);
			            })
						->get(array('asistentes.id'));
									
			$asistentes_ids_fin=array();
			foreach ($asistentes as $asistente) {
				array_push($asistentes_ids_fin, $asistente->id);
			}

			$asistentes=Asistente::whereIn('asistentes.id', $asistentes_ids_fin)
						->orderBy("id", 'asc')
				        ->skip($cant_asistentes_cargados)
				        ->take(10)
				        ->get();

			
		}	

        $lista=""; 

        if($asistentes->count()>0)
        {
	        foreach($asistentes as $asistente)
	        {
	        	$lista.=' <li id="" class="" style="cursor:pointer"><!-- start message --> 
	                        <a class="seleccionar-asistente" data-nombre="'.$asistente->nombre.'" data-id="'.$asistente->id.'">                                      
	                          <div class="col-lg-4  col-md-4 col-xs-4">
	                            <p>
	                            <b>CÓDIGO: </b>'.$asistente->id.'<br>
	                            <b>NOMBRE: </b> '.$asistente->nombre.'
	                            </p> 
	                          </div>  
	                          <div class="col-lg-8  col-md-8 col-xs-8">
	                            <b>TIPO DE ASISTENTE: </b> <br>';

							          if ($asistente->tipo_asistente_id==5)
							          {
							          	$lista.='<label class="label arrowed-right bg-purple" data-toggle="tooltip" data-placement="top" title="'.$asistente->tipoAsistente->nombre.'"><i class="fa fa-book" style="margin-right:15 px;"> </i></label>';
							          }elseif($asistente->tipo_asistente_id==4)
							          {
							          	$lista.='<label class="label arrowed-right bg-orange" data-toggle="tooltip" data-placement="top" title="'.$asistente->tipoAsistente->nombre.'"><i class="fa fa-star" style="margin-right:15 px;"> </i></label>';
							          }
							            
							           $lista.=' '.$asistente->tipoAsistente->nombre.'<br>';
							        
	            $lista.=     '</div> 
	                        </a>
	                     </li><!-- end message --> ';
	                    
	        }
	    }
        else
        {
        	$lista.='<li id="" class="" style="cursor:pointer">
	                    <div class="col-xs-12 col-md-12 col-lg-12  bg-gray" >
	                    <br>
	                      <center>	                      	
	                      		 <i class="fa fa-share-alt fa-2x"> </i> No hay asistentes que coincidan con la busqueda <b>"'.$buscar.'"</b> 	                      	
	                      </center>
	                     <br>
	                    </div>  
        			</li>';
        }
        $lista.=     '
                     <script type="text/javascript">
					  var cant_asistentes='.$asistentes->count().';
					</script>';
		return $lista; 
	}

	public function postCantidadAsistentesAjax($buscar="")
	{
		if($buscar=="")
		{
			$cant=Asistente::all()->count();
		}else
		{
            $buscar= htmlspecialchars($buscar);
			$buscar_array=explode(" ", $buscar);
			Global $sql_buscar;
			$c=0;
			foreach($buscar_array as $palabra)
			{
				if($c!=0)
					$sql_buscar.=" AND ";
				$sql_buscar.="(asistentes.nombre ILIKE '%$palabra%' OR asistentes.apellido ILIKE '%$palabra%'";
				if(ctype_digit($palabra))
					$sql_buscar.=" OR asistentes.id=$palabra";
				$sql_buscar.=")";
				$c++;
			}


			$asistentes = Asistente::where(function($query)
						{
			            	$sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			                $query->whereRaw($sql_buscar_l);
			            })
						->get(array('asistentes.id'));
									
			$asistentes_ids_fin=array();
			foreach ($asistentes as $asistente) {
				array_push($asistentes_ids_fin, $asistente->id);
			}

			$asistentes= Asistente::whereIn('asistentes.id', $asistentes_ids_fin)
						->orderBy("id", 'asc')
				        ->count();

		    $cant=$asistentes->count();
			
		}


		return $cant;
	}

	/////////////////aqui termina la parte de la busqueda tipo FACEBOOK







}
?>
