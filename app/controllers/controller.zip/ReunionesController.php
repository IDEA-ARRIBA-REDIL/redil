<?php
/** 
*
* @Redil Software. ReunionesController.php” 
* @versión: 1.0.0     @modificado: 29 de Octubre del 2014 
* @autor última modificación: Juan Carlos velasquez  
* 
*/
class ReunionesController extends BaseController
{


	public function __construct()
	{
		$this->beforeFilter('auth');  //bloqueo de acceso
	}


	public function getIndex()
	{
		return Redirect::to('reuniones/lista/todos');
	}

	public function getLista($tipo)
	{
		if(isset($_GET["buscar"]))
		{
			$cantidad_busqueda=0;
			$buscar= htmlspecialchars(Input::get("buscar"));
			$buscar_array=explode(" ", $buscar);
			Global $sql_buscar;
			$c=0;

			foreach($buscar_array as $palabra)
			{
				if($c!=0)
					$sql_buscar.=" AND ";

				$sql_buscar.=" (translate (reuniones.nombre, 'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñ', 'aeiouAEIOUaeiouAEIOUÑ') ILIKE '%$palabra%' OR reuniones.lugar ILIKE '%$palabra%' OR reuniones.descripcion ILIKE '%$palabra%'";
				
				if(ctype_digit($palabra))
				{
					$sql_buscar.=" OR reuniones.id=$palabra";
				}

				$busqueda_por_dia=false;

				if($palabra=="lunes")
				{
					$palabra=2;
					$busqueda_por_dia=true;
				}
				else if($palabra=="martes")
				{
					$palabra=3;
					$busqueda_por_dia=true;
				}
				else if ($palabra=="miercoles")
				{	
					$palabra=4;
					$busqueda_por_dia=true;
				}
				else if ($palabra=="jueves")
				{	
					$palabra=5;
					$busqueda_por_dia=true;
				}
				else if ($palabra=="viernes")
				{
					$palabra=6;
					$busqueda_por_dia=true;
				}
				else if ($palabra=="sabado")
				{	
					$palabra=7;
					$busqueda_por_dia=true;
				}
				else if ($palabra=="domingo")
				{	
					$palabra=1;
					$busqueda_por_dia=true;
				}

				if($busqueda_por_dia)
				$sql_buscar.=" OR reuniones.dia=$palabra";

				$sql_buscar.=")";
				$c++;
			}

			/////////////////////fin del codigo para crear la consultas

			$reuniones= Reunion::where(function($query)
			{
			    $sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			    $query->whereRaw($sql_buscar_l);
			})
			->orderBy('id', 'asc')
			->where('reuniones.dado_baja', '=', '0')
			
			->paginate(10);


			$cantidad_busqueda=$reuniones->count();


			return View::make('reuniones.index')-> with(
			array(
				'reuniones' => $reuniones,
				'buscar' => $buscar,
				'cantidad_busqueda' => $cantidad_busqueda,
			));

		}
		else
		{
			//$reunions = Reunion::where('dado_baja', '=', '0')->get(); //Reuniones no dadas de baja 
			$reuniones = Reunion::orderBy('id', 'asc')
			->where('reuniones.dado_baja', '=', '0')
			
			->paginate(10);

			$cantidad_todos= $reuniones->count();

			return View::make('reuniones.index')-> with(
				array(
					'reuniones' => $reuniones,
					'cantidad_todos' => $cantidad_todos,
					));
		}
	}

	public function getNuevo()
	{
		$reuniones =  Reunion::all();
		return  View::make('reuniones.nuevo')->with('reuniones', $reuniones);
	}

	public function postNew()
	{

		// -- creacion de la nueva reunion
	 	$nueva_reunion = new Reunion;
	 	$nueva_reunion->nombre = Input::get("nombre"); 
	 	$nueva_reunion->descripcion = Input::get("descripcion");	 	
	 	$nueva_reunion->hora = Input::get("hora");
	 	$nueva_reunion->dia = Input::get("dia");
	 	$nueva_reunion->lugar = Input::get("lugar"); 
	 	$nueva_reunion->dado_baja = 0;
	 	$nueva_reunion->save();
	 	// -- fin de creacion de la nueva reunion

		return Redirect::to('reuniones/nuevo')->with (array(
			'status'  => 'ok_update',
			'dia'=>$nueva_reunion->dia,
			));

	}

	public function getActualizar($id)
	{
		$reunion = Reunion::find($id);
			return View::make('reuniones.actualizar')->with(
				array('reunion' => $reunion));
	}

	public function postUpdate($id)
	{
		$reunion= Reunion::find($id);
		$reunion->nombre = Input::get("nombre"); 
	 	$reunion->descripcion = Input::get("descripcion");	 	
	 	$reunion->hora = Input::get("hora");
	 	$reunion->dia = Input::get("dia"); 	 	
	 	$reunion->lugar = Input::get("lugar"); 
	 	$reunion->save();

        return Redirect::to('reuniones/actualizar/'.$id)->with (array('status'  => 'ok_update'));
	}

    public function getDardebaja($id)
	{
		$reunion= Reunion::find($id);
		$reunion->dado_baja = 1;
	 	$reunion->save();

 		return Redirect::to('reuniones/lista/todos')->with (array(
 			'status'  => 'ok_down',
 			'nombre_reunion'=>$reunion->nombre,
 			));

	}

 	public function getPerfil($id)
	{
		$reunion = Reunion::find($id);
		if(!isset($reunion)) return App::abort(404);

		return View::make('reuniones.perfil')->with(
			array('reunion' => $reunion));;
	}

	public function getInformepdf($id)
	{
		$reunion=Reunion::find($id);
		$html=View::make('reuniones.pdf.informe_pdf')-> with(
			array('reunion' => $reunion));
	    return PDF::load(utf8_decode($html), 'letter', 'portrait')->show();	

	}

	/////////////////////////Esta es la parte de la busqueda tipo FACEBOOK de reuniones/////////////////////////////////////////////////////////
	//Metodo ajax: LineaSeleccionada
	//  Recibe como parámetro el id de la línea que se seleccione. 
	//  Retorna de forma grafica el nombre de la reunion, el codigo, el dia y la descripción(s)
	
	
	public function postReunionSeleccionada($id) 
	{
		App::setLocale('es'); 
		date_default_timezone_set('America/Bogota');
		$reunion=Reunion::find($id);
		$respuesta='<div class="item-seleccionado">';
		$respuesta.='<div id="ico-reunion" class="col-xs-4 col-md-3 col-lg-3 bg-blue" >';
        $respuesta.=   '<center><i class="fa fa fa-home fa-4x" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);"></i></center>';
        $respuesta.='</div>';
        $respuesta.='<div id="info-reunion" class="col-xs-8 col-md-9 col-lg-9 ">';
		$respuesta.='<h4><b>Reunion </b>'.$reunion->id.' - '.$reunion->nombre.'</h4>';
		$respuesta.='<p><b>Día: </b>';
		$dia=$reunion->dia;
        
        if($reunion->dia != 0 && $reunion->dia !="" ){
		$dia=Lang::choice('general.dias', $reunion->dia);
        }

		$respuesta.=$dia.'<br>';
		$respuesta.='<b>Descripción: </b>'.$reunion->descripcion.'<br>';
		$respuesta.='</p></div></div>';
		return $respuesta;
	}

	////////// este es el ajax que devuelve las siguientes 10 reuniones para el panel de reuniones 
	public function postObtieneReunionesParaBusquedaAjax($cant_reuniones_cargadas, $sql_adicional="", $buscar="")
	{
		App::setLocale('es'); 
		date_default_timezone_set('America/Bogota');

		$cant_reuniones=0;
		$prueba=0;
		if($buscar=="")
		{			
			$reuniones= Reunion::orderBy("id", 'asc')
			->where('reuniones.dado_baja', '=', '0')
	        
	        ->skip($cant_reuniones_cargadas)
	        ->take(10)
	        ->get();

		}else
		{

            $buscar= htmlspecialchars($buscar);
			$buscar_array=explode(" ", $buscar);
			Global $sql_buscar;
			$c=0;

			foreach($buscar_array as $palabra)
			{
				if($c!=0)
					$sql_buscar.=" AND ";

				$sql_buscar.=" (translate (reuniones.nombre, 'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñ', 'aeiouAEIOUaeiouAEIOUÑ') ILIKE '%$palabra%' OR reuniones.lugar ILIKE '%$palabra%' OR reuniones.descripcion ILIKE '%$palabra%'";
				
				if(ctype_digit($palabra))
				{
					$sql_buscar.=" OR reuniones.id=$palabra";
				}

				$busqueda_por_dia=false;

				if(strpos("lunes", $palabra)!== false)
				{
					$palabra=2;
					$busqueda_por_dia=true;
				}
				else if(strpos("martes", $palabra)!== false)
				{
					$palabra=3;
					$busqueda_por_dia=true;
				}
				else if (strpos("miercoles", $palabra)!== false)
				{	
					$palabra=4;
					$busqueda_por_dia=true;
				}
				else if (strpos("jueves", $palabra)!== false)
				{	
					$palabra=5;
					$busqueda_por_dia=true;
				}
				else if (strpos("viernes", $palabra)!== false)
				{
					$palabra=6;
					$busqueda_por_dia=true;
				}
				else if (strpos("sabado", $palabra)!== false)
				{	
					$palabra=7;
					$busqueda_por_dia=true;
				}
				else if (strpos("domingo", $palabra)!== false)
				{	
					$palabra=1;
					$busqueda_por_dia=true;
				}

				if($busqueda_por_dia)
				$sql_buscar.=" OR reuniones.dia=$palabra";

				$sql_buscar.=")";
				$c++;
			}

			$reuniones= Reunion::where(function($query)
			{
			    $sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			    $query->whereRaw($sql_buscar_l);
			})
			->where('reuniones.dado_baja', '=', '0')
			->orderBy('id', 'asc')
			
			->skip($cant_reuniones_cargadas)
			->take(10)
			->get();
		}	

        $lista=""; 

        if($reuniones->count()>0)
        {
	        foreach($reuniones as $reunion)
	        {
	        	$lista.=' <li id="" class="" style="cursor:pointer"><!-- start message --> 
	                        <a class="seleccionar-reunion" data-nombre="'.$reunion->nombre.'" data-id="'.$reunion->id.'">                                      
	                          <div class="col-lg-7  col-md-7 col-xs-7">
	                            <p style="white-space: normal !important">
	                            <b>CÓDIGO: </b>'.$reunion->id.'<br>
	                            <b>NOMBRE: </b> '.$reunion->nombre.'
	                            </p> 
	                          </div> 
	                          <div class="col-lg-5  col-md-5 col-xs-5">
	                          <b>Día: </b>';
	                          $dia=$reunion->dia;
        						if($dia != 0 && $dia !="" ){
								$dia=Lang::choice('general.dias', $dia);
        						}
								$lista.=$dia.'<br>';
				$lista.='<b>Hora: </b>'.$reunion->hora.'<br>';
							         
	            $lista.=     '</div> 
	                        </a>
	                     </li><!-- end message --> ';
	        }
	    }
        else
        {


        	$lista.='<li id="" class="" style="cursor:pointer">
	                    <div class="col-xs-12 col-md-12 col-lg-12  bg-gray" >
	                    <br>
	                      <center>	                      	
	                      		 <i class="fa fa-home fa-2x"> </i> No hay reuniones que coincidan con la búsqueda <b>"'.$buscar.'"</b> 	                      	
	                      </center>
	                     <br>
	                    </div>  
        			</li>';
        	
        }
        $lista.=     '
                     <script type="text/javascript">
					  var cant_registros='.$reuniones->count().';
					  var total_registros_ajax='.Reunion::where('dado_baja', '0')->count().';
					</script>';

		return $lista; 
	}

	public function postCantidadReunionesAjax($buscar="")
	{
		if($buscar=="")
		{
			$cant=Reunion::where('reuniones.dado_baja', '=', '0')
			->count();	
		}else
		{
            $buscar= htmlspecialchars($buscar);
			$buscar_array=explode(" ", $buscar);
			Global $sql_buscar;
			$c=0;

			foreach($buscar_array as $palabra)
			{
				if($c!=0)
					$sql_buscar.=" AND ";

				$sql_buscar.=" (translate (reuniones.nombre, 'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜñ', 'aeiouAEIOUaeiouAEIOUÑ') ILIKE '%$palabra%' OR reuniones.lugar ILIKE '%$palabra%' OR reuniones.descripcion ILIKE '%$palabra%'";
				
				if(ctype_digit($palabra))
				{
					$sql_buscar.=" OR reuniones.id=$palabra";
				}

				$busqueda_por_dia=false;

				if(strpos("lunes", $palabra)!== false)
				{
					$palabra=2;
					$busqueda_por_dia=true;
				}
				else if(strpos("martes", $palabra)!== false)
				{
					$palabra=3;
					$busqueda_por_dia=true;
				}
				else if (strpos("miercoles", $palabra)!== false)
				{	
					$palabra=4;
					$busqueda_por_dia=true;
				}
				else if (strpos("jueves", $palabra)!== false)
				{
					$palabra=5;
					$busqueda_por_dia=true;
				}
				else if (strpos("viernes", $palabra)!== false)
				{
					$palabra=6;
					$busqueda_por_dia=true;
				}
				else if (strpos("sabado", $palabra)!== false)
				{	
					$palabra=7;
					$busqueda_por_dia=true;
				}
				else if (strpos("domingo", $palabra)!== false)
				{	
					$palabra=1;
					$busqueda_por_dia=true;
				}

				if($busqueda_por_dia)
				$sql_buscar.=" OR reuniones.dia=$palabra";

				$sql_buscar.=")";
				$c++;
			}


			$cant= Reunion::where(function($query)
			{
			    $sql_buscar_l=$GLOBALS['sql_buscar']; /// sql_buscar_l local
			    $query->whereRaw($sql_buscar_l);
			})
			->where('reuniones.dado_baja', '=', '0')
			->count();
			
		}


		return $cant;
	}



	/////////////////aqui termina la parte de la busqueda tipo FACEBOOK

}
?>