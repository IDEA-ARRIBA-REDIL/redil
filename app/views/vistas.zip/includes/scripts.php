  <!-- jQuery 2.0.2 -->
<script src="/js/jquery-2.1.1.js"></script>
<!-- Bootstrap -->
<script src="/js/bootstrap.min.js" type="text/javascript"></script>

<!-- AdminLTE App -->
<script src="/js/AdminLTE/app.js" type="text/javascript"></script>

<script type="text/javascript">
	$(document).ready(function() {
		setTimeout(function() {
			$(".desvanecer").hide(500)
		}, 10000);
	});
</script>