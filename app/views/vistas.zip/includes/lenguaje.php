<?php   
App::setLocale('es'); 
date_default_timezone_set('America/Bogota');
?>