@if(Auth::check())
@include('includes.lenguaje')
<!DOCTYPE html>
<!-- Vista creada por: Felipe Fajardo
     Fecha creacíón: 24-04-2015
     Fecha Ultima modificación: 05-05-2015 12:05pm
     funcion vista: esta es la vista que contiene el listado de todas las ofrendas.
     software REDIL version 1.0
-->
<html>
<head>
  <meta charset="UTF-8">
  <title> Redil | Lista de ingresos</title>
  <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
  <!-- bootstrap 3.0.2 -->
  <link href="../../css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <!-- font Awesome -->
  <link href="../../css/font-awesome.min.css" rel="stylesheet" type="text/css" />
  <!-- Ionicons -->
  <link href="../../css/ionicons.min.css" rel="stylesheet" type="text/css" />
  <!-- DATA TABLES -->
  <link href="../../css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />

  <!-- Theme style -->
  <link href="../../css/AdminLTE.css" rel="stylesheet" type="text/css" />
  <link href="http://cdn.datatables.net/1.10.0/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond../js/1.3.0/respond.min.js"></script>
          <![endif]-->
        </head>
        <body class="skin-black">
          <!-- header logo: style can be found in header.less -->

          @include('includes.header')

          <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            

            <aside class="left-side sidebar-offcanvas">                
              <!-- sidebar: style can be found in sidebar.less -->
              <section class="sidebar">

                <!-- sidebar menu: : style can be found in sidebar.less -->

                @include('includes.menu')

              </section>
              <!-- /.sidebar -->
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
              <!-- contendio cabezote -->
              <section class="content-header">
                <div class="box-header"> <!-- Inicio del Box Header del Box Filtro -->
                  <div class="pull-right box-tools">
                     @if(Auth::user()->id==1)
                     <a href="/ofrendas/nuevo" class="btn btn-danger btn-md"> <i class="fa fa-plus"></i> Nuevo Ingreso </a>
                     @endif
                     <button data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Imprimir" onclick="window.print();"><i class="fa fa-print"></i></button>
                     <!-- <button data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Enviar por Email"><i class="fa fa-envelope"></i></button> -->
                     <button data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Generar Archivo PDF"><i class="fa fa-file-pdf-o "></i></button>
                     <button class="btn btn-danger btn-md" data-widget="collapse" data-toggle="tooltip" title="" data-original-title="Desplegar Filtros"><i class="fa fa-filter"></i></button>
                  </div>
                   
                  <h3 class=" content-header" style="font-size:24px">
                    LISTA DE INGRESOS 
                    <small style="font-size:15px; font-weight:300;"> Aquí encontrarás los movimientos financieros. </small>
                  </h3>
                </div> <!-- Fin de Box Header del Box Filtro -->
              </section>

              <div class="col-lg-12">
                <?php $status=Session::get('status'); 
                $ofrenda_id_eliminada=Session::get('ofrenda_id_eliminada'); 
                ?>
                @if($status=='ok_delete')
                <div class="alert alert-success col-lg-12 desvanecer" style="padding-bottom:5px; padding-top:5px; margin-bottom: -5px">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  El Ingreso con Id: {{$ofrenda_id_eliminada}} fue eliminado satisfactoriamente. 
                </div>
                @endif
              </div>
            <!-- /contendio cabezote -->

            <!-- contenido principal -->
            <section class="content">

              <!-- row de cuadro de colores -->
              <div class="row-fluid">
                <!-- cuadro todos -->
                <div class="col-lg-2 col-md-2 col-sm-4 col-xs-4 contador" data-toggle="tooltip" data-placement="top" >
                  <div class="small-box bg-yellow">
                    <div class="inner">
                      <h3>
                        <br>
                      </h3>
                      <p>
                        Todos
                      </p>
                    </div>
                    <div class="icon">
                      <i class="fa fa-certificate"></i>
                    </div>
                    <a href="todos" class="small-box-footer">Ver<i class="fa fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>
                <!-- /cuadro todos -->

                <!-- cuadro por reunion --> 
                <div class="col-lg-2 col-md-2 col-sm-4 col-xs-4 contador">
                  <div class="small-box bg-red">
                    <div class="inner">
                      <h3>
                        <br>
                      </h3>
                      <p>
                        Por reunion
                      </p>
                    </div>
                    <div class="icon">
                      <i class="fa fa-home"></i>
                    </div>
                    <a href="por-reunion" class="small-box-footer">Ver<i class="fa fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div><!-- /cuadro por reunion -->


                <!-- cuadro por grupo -->
                <div class="col-lg-2 col-md-2 col-sm-4 col-xs-4 contador">
                  <div class="small-box bg-teal">
                    <div class="inner">
                      <h3>
                        <br>
                      </h3>
                      <p>
                        Por grupo
                      </p>
                    </div>
                    <div class="icon">
                      <i class="fa fa-users"></i>
                    </div>
                    <a href="por-grupo" class="small-box-footer">Ver<i class="fa fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>
                <!-- /cuadro por grupo -->


                <!-- Cuadro otros -->
                <div class="col-lg-2 col-md-2 col-sm-4 col-xs-4 contador">
                  <div class="small-box bg-aqua">
                    <div class="inner">
                      <h3>
                        <br>
                      </h3>
                      <p>
                        Otros
                      </p>
                    </div>
                    <div class="icon">
                      <i class="fa fa-align-justify"></i>
                    </div>
                    <a href="otros" class="small-box-footer">Ver<i class="fa fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>
                <!-- /cuadro otros -->
 
              
                <?php $fecha_actual=new DateTime();
                $ano = $fecha_actual->format('Y');

                $mes = $fecha_actual->format('m');
                ?>

                <!-- cuadro año -->
                <div class="col-lg-2 col-md-2 col-sm-4 col-xs-4 contador">
                  <div class="small-box bg-blue">
                    <div class="inner">
                      <h3>
                      <?php $mes_nombre="Mes Actual";
                      if($mes==1)
                      $mes_nombre="Enero";
                      else if($mes==2)
                      $mes_nombre="Febrero";
                      else if($mes==3)
                      $mes_nombre="Marzo";
                      else if($mes==4)
                      $mes_nombre="Abril";
                      else if($mes==5)
                      $mes_nombre="Mayo";
                      else if($mes==6)
                      $mes_nombre="Junio";
                      else if($mes==7)
                      $mes_nombre="Julio";
                      else if($mes==8)
                      $mes_nombre="Agosto";
                      else if($mes==9)
                      $mes_nombre="Septiembre";
                      else if($mes==10)
                      $mes_nombre="Octubre";
                      else if($mes==11)
                      $mes_nombre="Noviembre";
                      else if($mes==12)
                      $mes_nombre="Diciembre";
                      ?>
                      {{ $mes_nombre }}
                      </h3>
                      <p>
                        Mes Actual
                      </p>
                    </div>
                    <div class="icon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <a href="mes" class="small-box-footer">Ver<i class="fa fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div>
                <!-- /cuadro año-->

                <!-- cuadro  Mes actual -->
                <div class="col-lg-2 col-md-2 col-sm-4 col-xs-4 contador">
                  <div class="small-box bg-orange">
                    <div class="inner">
                      <h3>
                        {{ $ano }}
                      </h3>
                      <p>
                        Año Actual
                      </p>
                    </div>
                    <div class="icon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <a href="año" class="small-box-footer">Ver<i class="fa fa-arrow-circle-right"></i>
                    </a>
                  </div>
                </div> 
                <!-- /cuadro  Mes actual -->
              </div>
              <!-- /row de cuadro de colores -->

              <!-- row de la tabla -->
              <div class="row">   

                <!-- div de 12 columnas -->                     
                <div class="col-xs-12">
                  <div class="box box-primary">
                    <div class="panel-body">
                      <!-- tabla -->
                      <div class="box-body table-responsive">

                        <!--<div class="collapse" id="busqueda-avanzada">
                          <div class="well">
                            Proximamente busqueda detallada ... 
                          </div>
                        </div>  --> 

                        <div class="col-md-8 col-xs-12">
                          @if(isset($buscar))
                          @if($buscar!="")
                          @if($cantidad_busqueda == 1)
                          <h4>La busqueda arrojo <b>{{ $cantidad_busqueda }}</b> ofrenda. </h4>
                          @else
                          <h4>La busqueda arrojo <b>{{ $cantidad_busqueda }}</b> ofrendas. </h4>
                          @endif                       
                          @endif
                          @endif
                          <form action="/ofrendas/lista/todos/" method="get" role="form" class="form-inline">
                            <div class="input-group">
                              <input type="text" id="buscar" name="buscar" class="form-control" value="{{ Input::get('buscar') }}" placeholder=" Busque aqui ..." >
                              <span class="input-group-btn">
                                @if(isset($buscar))
                                <a class="btn btn-danger" href="/ofrendas/lista/{{$tipo}}" type="submit"><i class="fa fa-times"></i></a>
                                
                                @endif 
                                <button class="btn btn-info" type="submit"><i class="fa fa-search"></i></button>
                                <!--<button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#busqueda-avanzada" aria-expanded="false" aria-controls="collapseExample">
                                 Busqueda avanzada 
                               </button>-->
                             </span>
                           </div>
                         </form>
                         
                       </div>  
                     </div> 
                     <br>
                     <br>

                     <table id="example1" class="table table-striped display " cellspacing="0" width="100%">
                      <thead>
                        <tr>
                         <th>Asistente</th>
                         <th>Valor</th>
                         <th>Información</th>
                         <th></th>
                       </tr>
                     </thead>
                     <tbody>

                       @foreach($ofrendas as $ofrenda)

                       <tr>

                        <td>
                          <?php $nombre_asistente=""; ?>
                          @if(isset($ofrenda->asistente->nombre))
                          <?php $nombre_asistente=$ofrenda->asistente->nombre." ".$ofrenda->asistente->apellido; ?>
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Codigo">Cod</label>  {{ $ofrenda->asistente_id }} <br>
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Nombre"> <i class="fa fa-user"></i></label>  {{ $nombre_asistente }}<br>
                          @if($ofrenda->asistente->dado_baja==1)
                          <label class="label arrowed-right label-danger" data-toggle="tooltip" data-placement="top" title="Dado de baja"> <i class="fa fa-minus-circle"></i></label> ASISTENTE DADO DE BAJA <br>
                          @endif
                          @else
                          <br> <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Ofrenda Suelta"> <i class="fa fa-user"></i></label>  OFRENDA SUELTA <br>
                          @endif

                        </td>

                        <td>

                          @if($ofrenda->tipo_ofrenda==0)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top"> Diezmo </label> <br>
                          @elseif($ofrenda->tipo_ofrenda==1)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top"> Ofrenda </label> <br>
                          @elseif($ofrenda->tipo_ofrenda==2)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top"> Pacto </label> <br>
                          @elseif($ofrenda->tipo_ofrenda==3)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top"> Pro-Templo </label> <br>
                          @elseif($ofrenda->tipo_ofrenda==4)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top"> Siembra </label> <br>
                          @elseif($ofrenda->tipo_ofrenda==5)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top"> Primicia </label> <br>
                          @elseif($ofrenda->tipo_ofrenda==6)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top"> Otro </label> <br>
                          @elseif($ofrenda->tipo_ofrenda==7)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top"> Suelta </label> <br>
                          @endif 

                          <h4><label class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title=""> <i class="fa fa-money"></i></label> {{ $ofrenda->valor }}  </h4><br>
                        </td>

                        <td>
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Fecha"> <i class="fa fa-calendar"></i></label> {{ $ofrenda->fecha }}<br>
                          @if ($ofrenda->ingresada_por==0)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Ingresado por"> Ingresado por </label> Reunión <br>
                          @elseif($ofrenda->ingresada_por==1)
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Ingresado por"> Ingresado por </label> Grupo <br>
                          @else
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Ingresado por"> Ingresado por </label> Otro <br>
                          @endif 
                        </td>

                        <td>
                         <div class="btn-group">
                         @if(Auth::user()->id==1)

                          <button type="button" class="btn btn-success btn-info dropdown-toggle" data-toggle="dropdown">
                            Opciones  
                            <i class="fa fa-caret-down"> </i>
                          </button>
                          <ul class="dropdown-menu">
                            <li><a href="../informe/{{$ofrenda->id}}">Ver Informe</a></li>
                            <li><a href="../actualizar/{{$ofrenda->id}}">Modificar</a></li>
                            <li><a class="eliminar" style="cursor:pointer" 
                              data-ofrenda-id="{{$ofrenda->id}}" data-ofrenda-valor="{{$ofrenda->valor}}"
                              data-ofrenda-tipo="{{$ofrenda->tipo_ofrenda}}" data-asistente-nombre="{{ $nombre_asistente }}"
                                >Eliminar</a></li>
                          </ul>
                          @else
                          <br>
                          <a href="../informe/{{$ofrenda->id}}" type="button" class="btn btn-success btn-info dropdown-toggle">
                          Ver Informe 
                          </a>
                          @endif
                        </div>
                      </td>
                    </tr>
                    @endforeach

                  </tbody>
                </table>
              </div>
              <!-- /tabla -->
            </div> <!-- /panel body -->

            <div class="box-footer">
              <div class="row">
                <div class="col-lg-4"> 
                  <h4> <b>{{ $ofrendas->getFrom() }}</b> - <b>{{ $ofrendas->getTo() }}</b> de <b>{{ $ofrendas->getTotal() }} </b> registros.</h4> 
                </div>
                @if(!isset($buscar))
                <div class="col-lg-8 text-right" style="padding-right: 30px!important;"> {{ $ofrendas->links() }}</div>
                @else
                <div class="col-lg-8 text-right" style="padding-right: 30px!important;"> {{ $ofrendas->appends(array('buscar' => $buscar))->links() }}</div>
                @endif

              </div>                  
            </div>

          </div><!-- /Box primary -->
        </div><!-- /Div de 12 columnas -->


  </section>
  <!-- contenido principal -->
</aside>  
</div><!-- /row -->

    <!-- /modal   -->
    <div id="confirmacion" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header" style="background:#F56954;color:white">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h3 style="font-size:20px">Eliminar Ingreso Financiero</h3>
            </div>
            <div class="modal-body" id="modal-body">
                  <h4 id="msn_confirmacion" class="modal-title bg-danger text-center" id="myModalLabel">  </h4>
      
            </div>
            <div class="modal-footer">
                <a href="#" id="si" type="button" class="btn btn-primary">Si</a>
                <button id="no" type="button" class="btn btn-danger" data-dismiss="modal">No</button>
            </div>
        </div>
      </div>
    </div>
    <!-- /modal   -->

<!-- incluye librerias script -->
@include('includes.scripts')

<!-- DATA TABES SCRIPT -->
<script src="http://cdn.datatables.net/1.10.0/js/jquery.dataTables.js" type="text/javascript"></script>
<script src="../../js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>


<!-- page script -->
<script type="text/javascript">

$(document).ready(function() {
$("#menu_ofrendas").attr('class', 'treeview active');
        $("#submenu_ofrendas").attr('style', 'display: block;');
        $("#flecha_ofrendas").attr('class', 'fa fa-angle-down pull-right');
        $(".eliminar").on('click', function(){
        $("#confirmacion").modal({show: 'true'});

var ofrenda_id=$(this).attr("data-ofrenda-id");
var ofrenda_valor=$(this).attr("data-ofrenda-valor");
var ofrenda_tipo=$(this).attr("data-ofrenda-tipo");
var asistente_nombre=$(this).attr("data-asistente-nombre");  


var tipo_de_ofrenda="el ingreso";
var sustantivo1="";
var sustantivo2="?";

if(ofrenda_tipo==0)
{
tipo_de_ofrenda="el diezmo";
sustantivo1=" ingresado por el(la) asistente ";
sustantivo2="de eliminarlo?";
}
else if(ofrenda_tipo==1)
{
tipo_de_ofrenda="la ofrenda";
sustantivo1=" ingresada por el(la) asistente ";
sustantivo2="de eliminarla?";
}
else if(ofrenda_tipo==2)
{
tipo_de_ofrenda="el pacto";
sustantivo1=" ingresado por el(la) asistente ";
sustantivo2="de eliminarlo?";
}
else if(ofrenda_tipo==3)
{
tipo_de_ofrenda="el ingreso de tipo pro-templo";
sustantivo1=" ingresado por el(la) asistente ";
sustantivo2="de eliminarlo?";
}
else if(ofrenda_tipo==4)
{
tipo_de_ofrenda="la siembra";
sustantivo1=" ingresada por el(la) asistente ";
sustantivo2="de eliminarla?";
}
else if(ofrenda_tipo==5)
{
tipo_de_ofrenda="la primicia";
sustantivo1=" ingresada por el(la) asistente ";
sustantivo2="de eliminarla?";
}
else if(ofrenda_tipo==6)
{
sustantivo1=" depositado por el(la) asistente ";
sustantivo2="de eliminarlo?";
}
else if(ofrenda_tipo==7)
{
tipo_de_ofrenda="la ofrenda suelta";
sustantivo1="";
sustantivo2="de eliminarla?";
}

$("#msn_confirmacion").html("Esta a punto de eliminar "+tipo_de_ofrenda+" con codigo "+ofrenda_id+sustantivo1+asistente_nombre+" por valor de $"+ofrenda_valor+"<br>Esta seguro "+sustantivo2);
$("#si").attr("href","../eliminar/"+ofrenda_id);
});
      
} );

</script>
@endif
</body>
</html>