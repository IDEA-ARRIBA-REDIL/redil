@if(Auth::check())
@include('includes.lenguaje')
<?php $id_integrante; ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Redil | Perfil de Reunión</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        @include('includes.styles')
        <!-- datepicker.css -->
        <link href="/css/datepicker.css" rel="stylesheet" type="text/css" />
        <link href="/css/datepicker3.css" rel="stylesheet" type="text/css" />
         <!-- DATA TABLES -->
        <link href="/css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        
    </head>
    <body class="skin-black">
        <!-- header logo: style can be found in header.less -->
        @include('includes.header')

        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    @include('includes.menu')
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- contendio cabezote -->

                  

              <section class="content-header">
                  <div class="box-header">
                    <div class="pull-right box-tools">
                      
                      @if(Auth::user()->id==1)
                        <div class="btn-group">
                          <button type="button" class="btn btn-success btn-info dropdown-toggle" data-toggle="dropdown">
                              {{ Lang::get('grupos.lg_bt_opciones') }}  
                              <i class="fa fa-caret-down"> </i>
                         </button>
                          <ul class="dropdown-menu">
                              <li><a href="../actualizar/{{$reporte->id}}">{{ Lang::get('grupos.lg_bt_opciones_1') }}</a></li>
                              <li><a href="../eliminar/{{$reporte->id}}">Eliminar</a></li>
                          </ul> 
                         </div>   
                        @endif                                            
                        <button data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Imprimir"  onclick="window.print();" ><i class="fa fa-print"></i></button>
                       <!-- <button data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Enviar por Email"><i class="fa fa-envelope"></i></button> -->
                        <a href="../informepdf/{{$reporte->id}}" target="_blank" data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Por medio de este botón podrás crear un archivo pdf con la información del informe"><i class="fa fa-file-pdf-o "></i></a>
                        <a  href="../lista/todos" class=" btn bg-red"> <i class="fa fa-undo"></i> Volver</a>
                    </div>
                    <h3 class="content-header barra-titulo">
                     RESUMEN REPORTE REUNIÓN
                      <small> Aquí podrás ver el perfil de la reunión @if(Auth::user()->id!=1) en base a tu ministerio @endif</small>
                    </h3> 
                      
                  </div>
              </section>

              <!-- contenido principal -->
              <section class="content">
                <div class="panel-default">
                  <div class="row-fluid">

                    <div class="col-lg-9 col-md-9 col-xs-8">
                      <div class="box-body text-left"> 
                         <!-- informacion Grupo inmediato-->
                         <div class="col-lg-12 col-sm-6 col-md-6 col-xs-12">
                           <h1 class="col-lg-12 no-padding no-margin"> 
                            Cod. de reporte {{ $reporte->id }} 
                               
                           </h1>  
                           <h3 class="page-header col-lg-12 no-padding"> {{ $reporte->reunion->nombre }}  </h3> 
                         </div>
                         <div class="col-lg-12 col-sm-6 col-md-6 col-xs-12">
                           <small class="label label-info col-lg-5 col-md-10 col-xs-12 col-sm-12" style="font-size: 14px; margin: 0 10px 10px 0;"><i class="fa fa-users"></i> 
                            Asistieron a la reunión: 
                            {{ $reporte->cantAsistentesTotal($reporte->id) }} </small>

                            @if(Auth::user()->id!=1)
                             <small class="label label-primary col-lg-5 col-md-10 col-xs-12 col-sm-12" style="font-size: 14px; margin: 0 10px 10px 0;"><i class="fa fa-users"></i> 
                             Asistieron de tu Ministerio:
                            {{ $cantidad_todos }} 
                              </small>
                            @endif  

                          </div>                        
                      </div>
                   </div>

                    <div class="col-lg-3 col-sm-3 col-md-3 col-xs-4">
                        <div class="small-box bg-teal"  style="color:white">
                                <div class="inner">
                                    <h3>
                                       
                                        <sub style="font-size: 16px;">Día</sub>
                                    </h3>
                                        
                                </div>
                                <div class="icon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <div class="small-box-footer">
                                    <h3>
                                    @if($reporte->reunion->dia != 0 && $reporte->reunion->dia !="" )
                                    {{ Lang::choice('general.dias', $reporte->reunion->dia) }} 
                                    @endif
                                    </h3>
                                </div>
                            </div>
                    </div>
                  </div>
                </div>
                    
                <!-- /contendio cabezote -->
                 
                <div class="row">
                   <!-- columna Reporte -->
                  <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                          <div class="box box-primary">
                              <div class="panel-heading">
                                  <h3 > <span class="badge bg-blue">  <i class="fa fa-info fa-2x"></i> </span>  Información del Reporte </h3>
                              </div>
                              
                              <div class="panel-body" style="margin-top:-25px;">
                                  
                                  <!-- /.fin Fecha de reunion -->
                                   <!-- predicaicon o tema -->
                                  <h4>
                                    <i class="fa fa-calendar"></i>  Fecha:  
                                      {{ $reporte->fecha }} 
                                   </h4>
                                    <!-- /predicaicon o tema -->
                                   <h4>
                                    @if(isset($reporte->predicador) && ($reporte->predicador!=""))
                                    <i class="fa fa-user"></i>  Predicador Principal:  
                                     {{ $reporte->asistentePredicador['nombre'] }} {{ $reporte->asistentePredicador['apellido'] }}
                                    @endif
                                    </h4>
                                    <h4>
                                    @if(isset($reporte->predicador_invitado) && ($reporte->predicador_invitado!=""))
                                    <i class="fa fa-male"></i>  Predicador Principal (Invitado):  
                                      {{ $reporte->predicador_invitado }} 
                                    @endif
                                    </h4>
                                    <h4>
                                    @if(isset($reporte->predicador_diezmos) && ($reporte->predicador_diezmos!=""))
                                    <i class="fa fa-user"></i>  Predicador de Diezmos:  
                                     {{ $reporte->asistentePredicadorDiezmos['nombre'] }} {{ $reporte->asistentePredicadorDiezmos['apellido'] }}
                                    @endif
                                    </h4>
                                    <h4>
                                    @if(isset($reporte->predicador_diezmos_invitado) && ($reporte->predicador_diezmos_invitado!="") )
                                    <i class="fa fa-male"></i>  Predicador de Diezmos (Invitado):  
                                      {{ $reporte->predicador_diezmos_invitado }} 
                                    @endif
                                   </h4>
                                    <h4>
                                    <i class="fa fa-info-circle"></i>  Observaciones:  
                                      {{ $reporte->observaciones }} 
                                   </h4>                                    

                            </div>    
                         </div>
                         
                  </div>
                  <!-- /columna  Reporte -->

                  <!-- columna Reunión -->
                  <div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
                          <div class="box box-warning">
                              <div class="panel-heading">
                                  <h3 > <span class="badge bg-orange">  <i class="fa fa-info fa-2x"></i> </span>  Información de la Reunión </h3>
                              </div>
                              
                              <div class="panel-body" style="margin-top:-25px;">
                                  
                                  <!-- /.fin Fecha de reunion -->
                                   <!-- predicaicon o tema -->
                                   <h4>
                                    <i class="fa fa-info-circle"></i>  Nombre:  
                                    <a href="../../reuniones/perfil/{{$reporte->reunion->id}}" style="color:#F39C12"> {{ $reporte->reunion->nombre }} </a> 
                                   </h4>
                                  <h4>
                                    <i class="fa fa-clock-o"></i>  Hora:  
                                      {{ $reporte->reunion->hora }} 
                                   </h4>
                                    <!-- /predicaicon o tema -->
                                    <h4>
                                    <i class="fa fa-home"></i>  Lugar:  
                                      {{ $reporte->reunion->lugar }} 
                                   </h4>
                                    <h4>
                                    <i class="fa fa-info-circle"></i>  Descripción:  
                                      {{ $reporte->reunion->descripcion }}                                   
                                    </h4>
                            </div>    
                         </div>
                         
                  </div>
                  <!-- /columna  Runión -->

                </div> 
                  
        <div class="row">   
          <!-- div de 12 columnas -->                     
          <div class="col-sm-12 col-lg-12 col-sx-12 col-md-12">
            <div class="box box-primary">


              <div class="col-lg-12" style="background:#fff">
          
                <!-- cuadro todos -->
                <div class="contadores" style=" margin-top: 10px;">
                  <div class="contador col-lg-2 col-md-2 col-xs-6" data-toggle="tooltip" data-placement="top" title= "Muestra todos los asistentes que asistieron a la reunión">
                    <div class="small-box bg-yellow">
                      <div class="inner">
                        <h3 id="cantidad-todos">{{ $cantidad_todos }}</h3>
                        <p>
                            {{ ucwords(Lang::choice('asistentes.tipo_asistente', 0)) }}
                        </p>
                      </div>
                      <div class="icon">
                          <i class="fa fa-certificate"></i>
                      </div>
                      <a id="porcentaje-todos" class="small-box-footer">@if($cantidad_total_asistentes!=0){{ (int) ($cantidad_todos/$cantidad_total_asistentes*100) }}% @if(Auth::user()->id==1) de la iglesia @else de tu ministerio @endif @else No hay asistentes registrados @endif
                      </a>
                    </div>
                  </div>
                  @if(Auth::user()->id!=1)
                  <?php $col=3;?>
                  <!-- cuadro nuevos -->
                    <div class="contador col-lg-2 col-md-2 col-xs-6" data-toggle="tooltip" data-placement="top" title= "Muestra todos los asistentes tipo Nuevo que asistieron a la reunión">
                      <div class="small-box bg-teal">
                            <div class="inner">
                                <h3 id="cantidad-nuevos" >
                                  {{ $cantidad_nuevos }}
                                </h3>
                                <p>
                                    {{ ucwords(Lang::choice('asistentes.tipo_asistente', 1)) }}
                                </p>
                            </div>
                        <div class="icon">
                          <i class="fa fa-heart"></i>
                        </div>
                          <a id="porcentaje-nuevos" class="small-box-footer">@if($cantidad_total_nuevos!=0) {{ (int) ($cantidad_nuevos/$cantidad_total_nuevos*100) }}% de los nuevos @else No hay nuevos registradas @endif
                          </a>
                      </div>
                    </div>
                    <!-- /cuadro nuevos -->
                  <!-- /cuadro todos -->
                  <div class="col-lg-8 no-padding">
                  @endif
                  
                  @if(Auth::user()->id==1) 
                  <!-- /cuadro todos -->
                  <div class="col-lg-10 no-padding">
                  <?php $col=2;?>
                    <!-- cuadro nuevos -->
                    <div class="contador col-lg-2 col-md-2 col-xs-6" data-toggle="tooltip" data-placement="top" title= "Muestra todos los asistentes tipo Nuevo que asistieron a la reunión">
                      <div class="small-box bg-teal">
                            <div class="inner">
                                <h3 id="cantidad-nuevos" >
                                  {{ $cantidad_nuevos }}
                                </h3>
                                <p>
                                    {{ ucwords(Lang::choice('asistentes.tipo_asistente', 1)) }}
                                </p>
                            </div>
                        <div class="icon">
                          <i class="fa fa-heart"></i>
                        </div>
                          <a id="porcentaje-nuevos" class="small-box-footer">@if($cantidad_total_nuevos!=0) {{ (int) ($cantidad_nuevos/$cantidad_total_nuevos*100) }}% de los nuevos @else No hay nuevos registradas @endif
                          </a>
                      </div>
                    </div>
                    <!-- /cuadro nuevos -->
                  @endif
                            
                    <!-- Cuadro ovejas -->
                    <div class="contador col-lg-{{ $col}} col-md-2 col-xs-6" data-toggle="tooltip" data-placement="top" title= "Muestra todos los asistentes tipo Oveja que asistieron a la reunión">
                      <div class="small-box bg-aqua">
                        <div class="inner">
                          <h3 id="cantidad-ovejas" >
                             {{ $cantidad_ovejas }}
                          </h3>
                          <p>
                              {{ ucwords(Lang::choice('asistentes.tipo_asistente', 2)) }}
                          </p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-group"></i>
                        </div>
                        <a id="porcentaje-ovejas" class="small-box-footer">@if($cantidad_total_ovejas!=0) {{ (int) ($cantidad_ovejas/$cantidad_total_ovejas*100) }}% de las ovejas @else No hay Ovejas registradas @endif
                        </a>
                      </div>
                    </div>
                    <!-- /cuadro ovejas -->
                            
                    <!-- cuadro miembros -->
                    <div class="contador col-lg-{{ $col}} col-md-2 col-xs-6" data-toggle="tooltip" data-placement="top" title= "Muestra todos los asistentes tipo Miembro que asistieron a la reunión">
                      <div class="small-box bg-blue">
                        <div class="inner">
                          <h3 id="cantidad-miembros" >
                            {{ $cantidad_miembros }}</h3>
                          <p>
                              {{ ucwords(Lang::choice('asistentes.tipo_asistente', 3)) }}
                          </p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-child"></i>
                        </div>
                        <a id="porcentaje-miembros" class="small-box-footer">@if($cantidad_total_miembros!=0) {{ (int) ($cantidad_miembros/$cantidad_total_miembros*100) }}% de los miembros @else No hay ningun miembro registrado @endif
                        </a>
                      </div>
                    </div>
                    <!-- /cuadro miembros-->
                            
                    <!-- cuadro lideres -->
                    <div class="contador col-lg-{{ $col}} col-md-2 col-xs-6" data-toggle="tooltip" data-placement="top" title= "Muestra todos los asistentes tipo Lider que asistieron a la reunión">
                      <div class="small-box bg-orange">
                        <div class="inner">
                        <h3 id="cantidad-lideres">
                          {{ $cantidad_lideres }}</h3>
                          <p>
                              {{ ucwords(Lang::choice('asistentes.tipo_asistente', 4)) }}
                          </p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-star"></i>
                        </div>
                        <a id="porcentaje-lideres" class="small-box-footer">@if($cantidad_total_lideres!=0) {{ (int) ($cantidad_lideres/$cantidad_total_lideres*100) }}% de los líderes @else No hay ningún lider registrado @endif
                        </a>
                      </div>
                    </div> 
                    <!-- /cuadro lideres -->

                    <!-- cuadro pastores -->
                    <div class="contador col-lg-{{ $col}} col-md-2 col-xs-6" data-toggle="tooltip" data-placement="top" title= "Muestra todos los asistentes tipo Pastor que asistieron a la reunión">
                      <div class="small-box bg-purple">
                        <div class="inner">
                            <h3 id="cantidad-pastores" >
                              {{ $cantidad_pastores }}</h3>
                            <p>
                                {{ ucwords(Lang::choice('asistentes.tipo_asistente', 5)) }}
                            </p>
                        </div>
                        <div class="icon">
                            <i class="fa fa-book fa-1x"></i>
                        </div>
                        <a id="porcentaje-pastores" class="small-box-footer">@if($cantidad_total_pastores) {{ (int) ($cantidad_pastores/$cantidad_total_pastores*100) }}% de los pastores @else No hay Pastores registrados @endif
                        </a>
                      </div>
                    </div>
                    <!-- /cuadro pastores -->

                    @if(Auth::user()->id==1)
                    <!-- cuadro invitados -->
                    <div class="contador col-lg-2 col-md-2 col-xs-6" data-toggle="tooltip" data-placement="top" title= "Muestra todos las personas que asistieron a la reunión pero que no estan registradas en el programa.">
                      <div class="small-box bg-redil">
                        <div class="inner">
                          
                            <h3 id="cantidad-invitados">
                              {{ $reporte->invitados }}</h3>

                            <p>
                                Invitados
                            </p>
                        </div>
                        
                        <a id="porcentaje-invitados" class="small-box-footer">@if($cantidad_total_asistentes) {{ (int)((int)$reporte->invitados/($cantidad_total_asistentes)*100) }}% @if(Auth::user()->id==1) de la iglesia @else de tu ministerio @endif @else No hay asistentes registrados @endif
                        </a>
                      </div>
                    </div>
                    <!-- /cuadro invitados -->
                  </div>
                  @else
                  </div>
                  @endif
                          
                </div>
              </div>
              <!-- cierra el div row -->
     



            <div id="contenido-ingresos" name="contenido-ingresos" class="row" style="background:#fff;margin-left:1px;margin-right:1px">
       
                                 
              <div style="margin-top:-40px" >

                <div class="col-lg-6 no-padding col-md-6 col-sm-6 col-xs-12">
                  <div class="col-lg-12 form-group pull-center text-center" >
                    <h1 > 
                      <span class="badge bg-blue">  
                      <i class="fa fa-user fa-4x"></i>
                      </span>
                    </h1>
                    <h4 class="no-margin">Búsqueda de Asistentes de la Reunión</h4>

                  </div>
                  <div class="col-lg-12" >
                    <!-- asistente --> 
                    <div class="nav navbar-nav" >
                        <li class="dropdown messages-menu">
                          <div class="input-group "  >
                              <input type="text" id="busqueda_predicador" class="form-control" autocomplete="off" onfocus="focusFunctionpredicador()" placeholder="Buscar predicador por código, nombre o cédula..." onkeydown="doSearchpredicador(arguments[0]||event)" />
                              <span class="input-group-btn">
                                  <button type='button' class="btn btn-flat" style="border-color:#CCC;background:#fff" ><i class="fa fa-search" style="color:#00545E" ></i></button>
                              </span>
                          </div> 

                          <ul id="panel-ppl-predicadores" class="panel-busqueda-moviles dropdown-menu " style="overflow: auto; width: 100%; max-height: 685px; position: relative; display:block;z-index:200">
                            <li>
                                <!-- inner menu: contains the actual data -->
                                <ul class="menu" id="panel-predicadores">
                                  @foreach($asistentes as $asistente)
                                  <li id="" class="" style="margin-top:20px;margin-right:-15px"><!-- start message -->
                                      
                                      <div class="col-lg-3" style="padding-right:0px !important;padding-left:0px !important">
                                      <center><img style="margin-right: -15px;" src="/img/fotos/{{ $asistente->foto }}" class="img-circle" width="70px" alt="User Image"></center> 
                                      </div>
                                      <div class="col-lg-5" style="padding-right:0px !important;padding-left:0px !important">
                                        <p style="white-space: normal !important">
                                         <b>CÓDIGO: </b>{{$asistente->id}}<br>
                                          <b>NOMBRE: </b>{{$asistente->nombre." ".$asistente->apellido}}
                                      </p>
                                      </div>
                                      <div class="col-lg-3" style="text-align:center;padding-right:0px !important;padding-left:0px !important;">
                                      <h4 style="margin-top:-3px">
                                         <?php
                                        $ofrendas_asistente=$asistente->ofrendas()->where('reporte_reunion_id', '=', $reporte->id)->get();
                                        $total_asistente=0;
                                        foreach ($ofrendas_asistente as $ofrenda_asistente) {
                                                     $total_asistente=$total_asistente+$ofrenda_asistente->valor;
                                                  }
                                        ?>
                                        <label id="ofrenda_{{$asistente->id}}" data-total-asistente="{{$total_asistente}}">  
                                         <br>
                                        <label id="ingresos_asistente" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">Ingresó: ${{$total_asistente}} </label>
                                      </label>
                                      </h4>
                                     </div> 

                                      <br>
                                      <br>
                                      <br>             
                                                       
                                    </li><!-- end message -->
                                    @endforeach
                                  </ul>
                                </li>
                            </ul>

                          </li>
                      </div>    
                    </div>
                </div>

                <!-- Sección de finanzas -->
                <div class="col-lg-6 no-padding col-md-6 col-sm-6 col-xs-12">
                  <div class="col-lg-12 form-group pull-center text-center" >
                    <h1 > 
                        <span class="badge bg-blue" style="background-color:#00A65A !important">  
                        <i class="fa fa-money fa-4x"></i>
                        </span>
                    </h1>
                    <h4 class="no-margin">Ingresos Financieros de la Reunión</h4>
                  </div>
                  <div class="col-lg-12">
                    <div class="box box-success">
                      <div class="panel-heading">
                          <h3 class="box-title"> <span class="badge bg-green">  <i class="fa fa-money fa-2x"></i> </span> Resumen Financiero</h3>
                      </div>
                        <div class="panel-body">
                            <table id="tabla_resumen_financiero" class="table table-condensedres table-hover" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>TIPO</th>
                                        <th>TOTAL</th>
                                        <th></th>
                                  </tr>
                                </thead>
                                <tbody>
                                           
                                    <tr>
                                        
                                        
                                        <td>
                                            <h4> Diezmos </h4>
                                        </td>

                                        <td>
                                            <h4><label id="total_diezmos" data-total="{{$total_diezmos}}" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">$</label> <label id="diezmos"> {{$total_diezmos}} </label> </h4> 

                                        </td>
                                            
                                         <td>
                                              
                                                                                
                                        </td>
                                        
                                    </tr>

                                     <tr>
                                        
                                        
                                        <td>
                                            <h4> Ofrendas </h4>
                                        </td>

                                        <td>
                                            <h4><label id="total_ofrendas" data-total="{{$total_ofrendas}}" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">$</label> <label id="ofrendas"> {{$total_ofrendas}} </label> </h4> 

                                        </td>
                                            
                                         <td>
                                              
                                                                                
                                        </td>
                                        
                                    </tr>
                                    <tr>
                                        
                                        
                                        <td>
                                            <h4> Pactos </h4>
                                        </td>

                                        <td>
                                            <h4><label id="total_pactos" data-total="{{$total_pactos}}" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">$</label> <label id="pactos"> {{$total_pactos}} </label> </h4> 

                                        </td>
                                            
                                         <td>
                                              
                                                                                
                                        </td>
                                        
                                    </tr>
                                    <tr>
                                        
                                        
                                        <td>
                                            <h4> Primicias </h4>
                                        </td>

                                        <td>
                                            <h4><label id="total_primicias" data-total="{{$total_primicias}}" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">$</label> <label id="primicias"> {{$total_primicias}} </label> </h4> 

                                        </td>
                                            
                                         <td>
                                              
                                                                                
                                        </td>
                                        
                                    </tr>
                                    <tr>
                                        
                                        
                                        <td>
                                            <h4> Pro-templo </h4>
                                        </td>

                                        <td>
                                            <h4><label id="total_protemplo" data-total="{{$total_protemplo}}" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">$</label> <label id="protemplo"> {{$total_protemplo}} </label> </h4> 

                                        </td>
                                            
                                         <td>
                                              
                                                                                
                                        </td>
                                        
                                    </tr>

                                    <tr>
                                        
                                        
                                        <td>
                                            <h4> Siembra </h4>
                                        </td>

                                        <td>
                                            <h4><label id="total_siembras" data-total="{{$total_siembras}}" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">$</label> <label id="siembras"> {{$total_siembras}} </label> </h4> 

                                        </td>
                                            
                                         <td>
                                              
                                                                                
                                        </td>
                                        
                                    </tr>

                                    <tr>
                                        
                                        
                                        <td>
                                            <h4> Otro </h4>
                                        </td>

                                        <td>
                                            <h4><label id="total_otros" data-total="{{$total_otros}}" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">$</label> <label id="otros"> {{$total_otros}} </label> </h4> 

                                        </td>
                                            
                                         <td>
                                              
                                                                                
                                        </td>
                                        
                                    </tr>
                                    
                                    <tr>
                                        <td>
                                            <h4> Ofrendas sueltas </h4>
                                        </td>

                                        <td>
                                            <h4><label id="total_ofrendas_sueltas" data-total="{{$total_ofrendas_sueltas}}" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">$</label> <label id="sueltas"> {{$total_ofrendas_sueltas}} </label> </h4> 
                                        </td>
                                            
                                         <td> 
                                                                                           
                                        <!--
                                            <input name="ofrenda_suelta" type="number" class="form-control" placeholder="$" data-toggle="tooltip" data-placement="top" title="Si hay ofrenda suelta ingrese el valor en este campo, de lo contrario simplemente dejelo vacio"/>
                                        --></td>
                                        
                                    </tr>

                                     <tr>
                                        <td class="text-right">
                                            <h4><b>TOTAL</b></h4>
                                        </td>

                                        <td>
                                            <h4><label id="total_ingresos" data-total="{{$total_ingresos}}" class="label arrowed-right label-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="">$</label> <label id="total"> {{$total_ingresos}} </label> </h4> 
                                        </td>
                                            
                                         <td>
                                        </td>

                                    </tr>
                                </tbody>
                                
                            </table>
                        </div> <!-- /box-body -->
                    </div>        
                  </div>
                </div> <!-- Fin Sección de finanzas -->
            

            </div>
                 
          </div><!-- Cierre div contenido-ingresos-->
                                      <!-- /cierra row  --> 
            </div><!-- /Box primary -->
        </div><!-- /Div de 12 columnas -->
      </div><!-- /row -->
      </section>  

    </div><!-- /Box primary -->
  </div><!-- /Div de 12 columnas -->
</div><!-- /row -->




                            
        

        @include('includes.scripts')
       
        

         <!-- DATA TABES SCRIPT -->
         <script src="{{ Lang::get('general.url-datatables') }}" type="text/javascript"></script>
        <script src="/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
        <script src="/js/plugins/datatables/jquery.dataTables.min.js" type="text/javascript"></script>
        
        <!-- bootstra datepicker-->
        <script src="/js/bootstrap-datepicker.js"></script>
        <script src="/js/locales/bootstrap-datepicker.es.js"></script>


  <!-- page script -->
            <script type="text/javascript">

//Script para cargar el predicador con busqueda estilo facebook

                  var idreporte = $("#reporte").attr("reporte-id");
                  var tiempoTranscurridopredicador;
                  var busqueda_predicador=""; // variable que va a ser llena con lo que tenga el input llamado "busqueda_predicador"
                  var bandera_predicador=0;
                  var winpredicador=$("#panel-ppl-predicadores");
                  var altopredicador=$("#panel-predicadores").height();
                  var cant_predicadores_cargados=10;
                  var total_predicadores=0;

                  var banderainput1=1;

                  //Variables para la busuqeda de asistentes a la reuniòn
                  var busqueda_asistente="";  
                  var bandera_asistente=0;
                  var altoasistente=$("#panel-asistentesreunion").height();
                  var cant_asistentes_cargados=10;
                  var total_asistentes=0;
                  var banderainput3=0;

                  total_predicadores={{ Asistente::where('asistentes.dado_baja', '=', '0')->count() }};
                  if(total_predicadores<=cant_predicadores_cargados)
                    bandera_predicador=1;


                  total_asistentes={{ Asistente::where('asistentes.dado_baja', '=', '0')->count() }};
                  if(total_asistentes<=cant_asistentes_cargados)
                    bandera_asistente=1;


                  function focusFunctionpredicador() {
                    $("#panel-ppl-predicadores").fadeIn(100);
                    banderainput1=1;
                    banderainput3=0;
                  }
                  
                  function doSearchpredicador(ev){
                    if(tiempoTranscurridopredicador)
                    {
                      clearTimeout(tiempoTranscurridopredicador);
                    }
                    tiempoTranscurridopredicador = setTimeout(buscarasistente,150);
                  }

  

                  function focusFunctionasistentereunion() {
                    $("#panel-ppl-asistentesreunion").fadeIn(100);
                    banderainput3=1;
                    banderainput1=0;
                  }

                  function buscarasistente(){

                      busqueda_predicador=$("#busqueda_predicador").val();
                      cant_predicadores_cargados=0;
                      $("#panel-predicadores li").remove(); 
                      $("#panel-predicadores").append("<li id='cargando-notif'><center><img class='img-responsive' width='30px' src='/img/ajax-loader.gif' /><center></li>");
                    
                      if(busqueda_predicador!=""){
                                var urlpredicador="/asistentes/obtiene-asistentes-ajax/"+cant_predicadores_cargados+"/asistentereunion/"+busqueda_predicador+"/"+idreporte+"/perfil";
                                var urlpredicador2="/asistentes/cantidad-asistentes-ajax/"+busqueda_predicador+"/"+idreporte+"/asistentereunion";
                              }
                              else{
                                var urlpredicador="/asistentes/obtiene-asistentes-ajax/"+cant_predicadores_cargados+"/asistentereunion/0/"+idreporte+"/perfil";
                                var urlpredicador2="/asistentes/cantidad-asistentes-ajax/0/"+idreporte+"/asistentereunion";
                              }

                    $.ajax({url:urlpredicador, cache:false, type:"POST",success:function(resp)
                      {

                        $("#panel-predicadores li").remove();
                        $("#panel-predicadores").append(resp);  
                        /////// icono cargando
                        $("#panel-predicadores #cargando-notif").remove();
                        
                        altopredicador=$("#panel-predicadores").height()-685;   
                       
                        cant_predicadores_cargados=cant_asistentes;  // cantidad_asistentes es enviada desde el controlador.               
                        
                        $.ajax({url:urlpredicador2, cache:false, type:"POST",success:function(resp)
                          {
                            total_predicadores=resp;
                            //////bandera se enciende siempre y cuando hayan mas registros por mostrar
                           if(cant_predicadores_cargados>= total_predicadores){
                              bandera_predicador=1;
                            }else
                              bandera_predicador=0;
                            }
                        });
                      }
                    });
                    $("#panel-ppl-predicadores").scrollTop(0);

                  }

                //Finaliza el script para cargar el predicador con busqueda estilo facebook

                $(document).ready(function() {

                      $("#ico-asistente").css("height", $("#info-asistente").height());

                      ////en caso de que se de clic en el input de busqueda o en el panel se anulara el evento de cerrar el panel
                      $('#busqueda_predicador').click(function (e) {
                        e.stopPropagation();
                      });

                      $("#busqueda_predicador").focusin(function() {
                        setTimeout(function() {
                          altopredicador=$("#panel-predicadores").height()-685;
                        
                        }, 100);

                      });

                      altopredicador=0;
                      winpredicador.scroll(function () {
                          if (winpredicador.scrollTop() > altopredicador && bandera_predicador==0) {
                              bandera_predicador=1;

                          $("#panel-predicadores li:last").after("<li id='cargando-notif'><center><img class='img-responsive' width='30px' src='/img/ajax-loader.gif' /><center></li>");
                              if(busqueda_predicador!=""){
                                var urlpredicador="/asistentes/obtiene-asistentes-ajax/"+cant_predicadores_cargados+"/asistentereunion/"+busqueda_predicador+"/"+idreporte+"/perfil";
                                var urlpredicador2="/asistentes/cantidad-asistentes-ajax/"+busqueda_predicador+"/"+idreporte+"/asistentereunion";
                              }
                              else{
                                var urlpredicador="/asistentes/obtiene-asistentes-ajax/"+cant_predicadores_cargados+"/asistentereunion/0/"+idreporte+"/perfil";
                                var urlpredicador2="/asistentes/cantidad-asistentes-ajax/0/"+idreporte+"/asistentereunion";
                              }

                              $.ajax({url:urlpredicador, cache:false, type:"POST",success:function(resp)
                                {     

                                  $("#panel-predicadores li:last").after(resp);
                                  /////// icono cargando
                                  $("#panel-predicadores #cargando-notif").remove();
                                  altopredicador=$("#panel-predicadores").height()-685;
                                  cant_predicadores_cargados+=10;

                                  $.ajax({url:urlpredicador2, cache:false, type:"POST",success:function(resp)
                                    {
                                      total_predicadores=resp;
                                      //////bandera se enciende siempre y cuando hayan mas registros por mostrar
                                     
                                      if(cant_predicadores_cargados<total_predicadores){
                                        bandera_predicador=0;  
                                      }
                                      ///este es el codigo es para seleccionar y mostrar de forma grafica el asistente seleccionado.  
                                      
                                    }
                                  });
                                }
                              });
                          }
                      });


                });

        </script>


    </body>
</html>

@endif