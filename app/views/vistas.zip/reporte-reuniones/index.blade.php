@if(Auth::check())
@include('includes.lenguaje')
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Redil |  Lista de Cultos </title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        @include('includes.styles')
         <!-- DATA TABLES -->
        <link href="/css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
       <!-- iCheck for checkboxes and radio inputs -->
        <link href="/css/iCheck/all.css" rel="stylesheet" type="text/css" />
        <!-- bootstrap multiselect-->
        <link rel="stylesheet" href="/css/bootstrap-multiselect.css" type="text/css"/>

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->

    </head>
    <body class="skin-black">
         @include('includes.header')
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <aside class="left-side sidebar-offcanvas">                
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">                   
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    @include('includes.menu')
                </section>
                <!-- /.sidebar -->
            </aside>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">                
                <!-- contendio cabezote -->
                <section class="content-header">   
                    <div class="box" style="background-color:transparent; border:none; box-shadow:none; margin-left:-5px; margin-bottom:-40px; ">
                        <div class="box-header">
                            <div class="pull-right box-tools" >
                                @if(Auth::user()->id==1)<a href="../nuevo" class="btn btn-danger btn-md"> <i class="fa fa-plus"></i> Nuevo Reporte </a>@endif
                                <button data-toggle="tooltip" title="" class="btn btn-info" data-original-title=" {{ Lang::get('general.dot_imprimir') }} "  onclick="window.print();" ><i class="fa fa-print"></i></button>
                                <a href="#"  data-toggle="tooltip" title="" class="btn btn-info" data-original-title=" {{ Lang::get('general.dot_pdf') }} "><i class="fa fa-file-pdf-o "></i></a>
                            </div>  
                            <h3 class="content-header" style="font-size:24px">
                                 Lista de Reportes de Cultos
                                <small> Aquí encontrarás la lista de los reportes de las reuniones. </small>
                            </h3>
                        </div>
                    </div>
                </section>
                <!-- /contendio cabezote --> 
                <br>
                <!-- contenido principal -->
                <section class="content">
                    <!-- row de la tabla -->
                    <div class="row"> 
                        <div class="col-lg-12">  
                            <div class="box box-primary"> 
                                <div class="panel-body">
                                    <!-- tabla -->
                                    <div class="box-body table-responsive">
                                        <div class="collapse" id="busqueda-avanzada">
                                          <div class="well">
                                            Proximamente busqueda detallada ... 
                                          </div>
                                        </div>   
                                        <!-- div de busqueda-->
                                        <div class="col-md-8 col-xs-12">
                                            @if(isset($buscar))
                                                @if($buscar!="")
                                                    @if($cantidad_busqueda == 1)
                                                       <h4>La busqueda arrojo <b>{{ $cantidad_busqueda }}</b> reunión. </h4>
                                                     @else
                                                       <h4>La busqueda arrojo <b>{{ $cantidad_busqueda }}</b> reuniones. </h4>
                                                     @endif  
                                                @endif
                                            @endif
                                          <form action="/reporte-reuniones/lista/todos" method="get" role="form" class="form-inline">
                                            <div class="input-group">
                                                
                                                <input type="text" id="buscar" name="buscar" class="form-control" value="{{ Input::get('buscar') }}" placeholder=" Busque aqui ..." >
                                                <span class="input-group-btn">
                                                    @if(isset($buscar))
                                                    <a class="btn btn-danger" href="/reuniones/lista/todos" type="submit"><i class="fa fa-times"></i></a>
                                                    @endif
                                                    <button class="btn btn-info" type="submit"><i class="fa fa-search"></i></button>
                                                    <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#busqueda-avanzada" aria-expanded="false" aria-controls="collapseExample">
                                                     Busqueda avanzada 
                                                    </button>
                                                </span>
                                            </div>
                                          </form>
                                        </div>
                                        <!-- fin div de busqueda-->
                                        
                                        <!-- div vacio-->
                                        <div class="col-md-4">
                                          
                                        </div>
                                         <!-- fin vacio-->
                                         
                                         <br><br>
                                         <!-- div de paginacion-->
                                        <div class="col-md-12  col-xs-12">
                                            <h4 ALIGN=right> Página<b>{{ $reporte_reuniones->getCurrentPage() }}</b> de <b>{{ $reporte_reuniones->getLastPage() }}</b>  </h4>                                           
                                        </div>
                                        <!-- fin de paginacion-->
                                        <table id="example1" class="table table-striped display " cellspacing="0" width="100%">
                                            <thead>
                                                <tr>  
                                                  <th>Información Principal</th>
                                                    <th>Predicadores</th>
                                                    <th>Especificaciones de Reunión</th>                                                                                                    
                                                    <th></th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                             @foreach($reporte_reuniones as $reporte)     
                                                <tr>                                                    
                                                    <td style="width:25%">
                                                      <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title= " Código ">Cod</label> {{ $reporte->id }}<br>
                                                        <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title= " Nombre "> <i class="fa fa-home"> </i>Nombre</label> {{ $reporte->reunion->nombre }} <br>       
                                                        <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Fecha"> <i class="fa fa-calendar"></i></label> {{ $reporte->fecha }}<br>                                                                    
                                                    </td>

                                                    <td style="width:45%">
                                                        @if(isset($reporte->predicador_invitado) && ($reporte->predicador_invitado!=""))
                                                        <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title= " Hora "><i class="fa fa-male"></i> Predicador Principal</label> {{ $reporte->predicador_invitado }} (Invitado)<br> 
                                                        @else
                                                         <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title= " Hora "><i class="fa fa-user"></i> Predicador Principal</label> {{ $reporte->asistentePredicador['nombre'] }} {{ $reporte->asistentePredicador['apellido'] }}<br> 
                                                        @endif 
                                                        @if(isset($reporte->predicador_diezmos_invitado) && ($reporte->predicador_diezmos_invitado!=""))
                                                        <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title= " Día "><i class="fa fa-male"></i> Predicador de Diezmos</label> {{ $reporte->predicador_diezmos_invitado }} (Invitado)<br>   
                                                        @else
                                                        <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title= " Día "><i class="fa fa-user"></i> Predicador de Diezmos</label> {{ $reporte->asistentePredicadorDiezmos['nombre'] }} {{ $reporte->asistentePredicadorDiezmos['apellido'] }}<br>   
                                                        @endif
                                                    </td>
                                                    
                                                    <td style="width:30%">

                                                        <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title= " Lugar "><i class="fa fa-users"> </i> Total de Asistentes</label> {{ $reporte->cantAsistentesTotal($reporte->id) }} <br> 
                                                        @if(Auth::user()->id!=1)
                                                        <?php
                                                        $grupos_ids=Auth::user()->asistente->gruposMinisterio('array');
                                                        $cant_asistentes=$reporte->asistentes()->whereIn('grupo_id', $grupos_ids)->count();
                                                        ?>
                                                        <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title= " Lugar "><i class="fa fa-users"> </i> Asistentes de tu Ministerio</label> {{ $cant_asistentes }} personas <br> @endif
                                                        <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title=" Descripción "><i class="fa fa-info-circle"> </i> Observaciones</label> {{ $reporte->observaciones }} personas<br>
                                                    </td>

                                                    <td>
                                                        <div class="btn-group">

                                                            <button type="button" class="btn btn-success btn-info dropdown-toggle" data-toggle="dropdown">
                                                                Opciones  
                                                                <i class="fa fa-caret-down"> </i>
                                                           </button>
                                                            <ul class="dropdown-menu">
                                                                
                                                                    <li><a href="../perfil/{{$reporte->id}}"> Ver Perfil </a></li>
                                                                    @if(Auth::user()->id==1)
                                                                    <li><a href="../actualizar/{{$reporte->id}}"> Modificar </a></li>
                                                                    <li><a href="../dado-baja-alta/{{$reporte->id}}"> Eliminar </a></li> 
                                                                    @endif                                                           
                                                            </ul>
                                                        </div>
                                                    </td> 
                                                </tr>
                                               @endforeach
                                            </tbody>  
                                        </table>
                                    </div>
                                    <!-- /tabla -->
                                </div>
                                <div class="box-footer">                                   
                                    <div class="row">                                        
                                        <div class="col-lg-4">                                            
                                          <h4> <b>{{ $reporte_reuniones->getFrom() }}</b> - <b>{{ $reporte_reuniones->getTo() }}</b> de <b>{{ $reporte_reuniones->getTotal() }} </b> registros.</h4> 
                                        </div>
                                        @if(!isset($buscar))
                                        <div class="col-lg-8 text-right" style="padding-right: 30px!important;"> {{ $reporte_reuniones->links() }}</div>
                                        @else
                                        <div class="col-lg-8 text-right" style="padding-right: 30px!important;"> {{ $reporte_reuniones->appends(array('buscar' => $buscar))->links() }}</div>
                                        @endif
                                    </div>
                                </div>
                            
                        </div>
                        <!-- /div de 12 columnas -->
                    </div>
                  <!-- /row de la tabla -->
                </section>
                <!-- contenido principal -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        @include('includes.scripts')   

        <!-- DATA TABES SCRIPT -->
        <script src="{{ Lang::get('general.url-datatables') }}" type="text/javascript"></script>
        <script src="/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
       <!-- bootstrap multiselect -->
        <script type="text/javascript" src="/js/bootstrap-multiselect.js"></script>
     
        
        <!-- page script -->
        <script type="text/javascript">
      
            $(document).ready(function() {
                $('.multiselectRedes').multiselect();
                $("#menu_reuniones").attr('class', 'treeview active');
                $("#submenu_reuniones").attr('style', 'display: block;');
                $("#flecha_reuniones").attr('class', 'fa fa-angle-down pull-right');

      } );

        </script>

        
        
    </body>
</html>
@endif