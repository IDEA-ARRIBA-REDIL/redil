@if(Auth::check())
@include('includes.lenguaje')
<!DOCTYPE html>
<html>
  <head>
      <meta charset="UTF-8">
      <title>Redil | Lista de reportes</title>
      <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
      @include('includes.styles')
       <!-- DATA TABLES -->
      <link href="/css/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
      
      <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
      <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
      <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
      <![endif]-->
  </head>
  <body class="skin-black">
    <!-- header logo: style can be found in header.less -->
    @include('includes.header')
    <div class="wrapper row-offcanvas row-offcanvas-left">
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="left-side sidebar-offcanvas">                
      <!-- sidebar: style can be found in sidebar.less -->
      <section class="sidebar">
          @include('includes.menu')
      </section>
      <!-- /.sidebar -->
    </aside>
    <!-- Right side column. Contains the navbar and content of the page -->
    <aside class="right-side">                
      <!-- contendio cabezote -->
      <section class="content-header">
        <div class="box box-filtro" >
          <div class="box-header">
            <div class="pull-right box-tools" >
              <a href="../nuevo" class="btn btn-danger btn-md"> <i class="fa fa-plus"></i> Nuevo Reporte </a>
              <button data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Imprimir"  onclick="window.print();" ><i class="fa fa-print"></i></button>
              <!--<button data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Enviar por Email"><i class="fa fa-envelope"></i></button> -->
              <button data-toggle="tooltip" title="" class="btn btn-info" data-original-title="Generar Archivo PDF"><i class="fa fa-file-pdf-o "></i></button>
             
            </div>
            <h3 class="content-header" style="font-size:24px">
              LISTA DE REPORTES DE GRUPOS
              <small>Aqui encontraras la lista de los reportes de los grupos activos. </small></h3>
            </h3>  
          </div>
                  
          <div class="box-body">
          </div>
        </div>
      </section>
      <!-- /contendio cabezote -->
      
      <!-- contenido principal -->
      <section class="content">
        <!-- row de la tabla -->
        <div class="row">   
          <!-- div de 12 columnas -->                    
          <div class="col-xs-12">
            <div class="box box-primary">
              <div class="panel-body">
                <!-- tabla lista-->
                <div class="box-body table-responsive">
                  <div class="collapse" id="busqueda-avanzada">
                    <div class="well">
                      Proximamente busqueda detallada ... 
                    </div>
                  </div>  
                  <!-- div de busqueda-->
                  <div class="col-md-8 col-xs-12">
                      @if(isset($buscar))
                          @if($buscar!="")
                              @if($cantidad_busqueda == 1)
                                 <h4>La busqueda arrojo <b>{{ $cantidad_busqueda }}</b> grupo. </h4>
                               @else
                                 <h4>La busqueda arrojo <b>{{ $cantidad_busqueda }}</b> grupos. </h4>
                               @endif  
                          @endif
                      @endif
                    <form action="/reporte-grupos/lista/todos/" method="get" role="form" class="form-inline">
                      <div class="input-group">
                          
                          <input type="text" id="buscar" name="buscar" class="form-control" value="{{ Input::get('buscar') }}" placeholder=" Busque aqui ..." >
                          <span class="input-group-btn">
                              @if(isset($buscar))
                               <a class="btn btn-danger" href="/reporte-grupos/lista/todos" type="submit"><i class="fa fa-times"></i></a>
                              @endif
                              <button class="btn btn-info" type="submit"><i class="fa fa-search"></i></button>
                              <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#busqueda-avanzada" aria-expanded="false" aria-controls="collapseExample">
                               Busqueda avanzada 
                              </button>
                          </span>
                      </div>
                    </form>
                  </div>
                  <!-- fin div de busqueda-->
                  
                  <!-- div vacio-->
                  <div class="col-md-4">
                    
                  </div>
                   <!-- fin vacio-->
                   
                   <br><br>
                   <!-- div de paginacion-->
                  <div class="col-md-12  col-xs-12">
                      <h4 ALIGN=right> Página<b>{{ $reportes->getCurrentPage() }}</b> de <b>{{ $reportes->getLastPage() }}</b>  </h4>                                           
                  </div>
                  <!-- fin de paginacion-->

                 
                                      
                  <table id="lista-reportes" class="table table-striped display " cellspacing="0" width="100%">
                    <thead>
                      <tr>
                      	<th>INFORMACIÓN</th>
                        <th>GRUPO REPORTADO</th>
                        <th>ASISTENCIA</th>
                        <th>OBSERVACIÓN</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      @foreach( $reportes as $reporte)
                      <tr>
                        <td>

                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Fecha del reporte de Grupo AAAA-MM-DD"> <i class="fa fa-calendar"></i> </label>  {{ date("Y-m-d", strtotime($reporte->fecha) );  }} <br> 
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Numero del reporte">N° Reporte:</label> {{ $reporte->id }}<br>   
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Tema o predicación"> <i class="fa fa-bookmark"></i> Tema:</label>  {{ $reporte->tema }} <br>
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Finanzas"> <i class="fa fa-money"></i>  Finanzas:</label>  {{ $reporte->ofrendas()->sum('valor') }} <br>
                        </td>
                        <td>
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Codigo de grupo">Grupo</label>  <b> {{ $reporte->grupo['id']}} - </b> {{$reporte->grupo['nombre'] }}  <br>                     
                          <?php $grupo= Grupo::find($reporte->grupo['id']);?> 
                          @foreach($grupo->encargados as $encargado)   
                             @if ($encargado->tipoAsistente['id']==5)
                                <label class="label arrowed-right" style="background-color: purple;" data-toggle="tooltip" data-placement="top" title="{{ $encargado->tipoAsistente['nombre'] }}"> <i class="fa fa-book"></i> {{ $encargado->tipoAsistente['nombre'] }}</label> 
                             @elseif($encargado->tipoAsistente['id']==3)
                                 <label class="label arrowed-right bg-blue" data-toggle="tooltip" data-placement="top" title="{{ $encargado->tipoAsistente['nombre'] }}"><i class="fa fa-child"></i> {{ $encargado->tipoAsistente['nombre'] }}</label> 
                                     
                             @elseif($encargado->tipoAsistente['id']==4)
                                 <label class="label arrowed-right bg-orange" data-toggle="tooltip" data-placement="top" title="{{ $encargado->tipoAsistente['nombre'] }}"><i class="fa fa-star-o"></i> {{ $encargado->tipoAsistente['nombre'] }}</label> 
                             @elseif($encargado->tipoAsistente['id']==2)
                                 <label class="label arrowed-right bg-aqua" data-toggle="tooltip" data-placement="top" title="{{ $encargado->tipoAsistente['nombre'] }}"><i class="fa fa-group"></i> {{ $encargado->tipoAsistente['nombre'] }} </label> 

                             @elseif($encargado->tipoAsistente['id']==1)
                                 <label class="label arrowed-right bg-teal" data-toggle="tooltip" data-placement="top" title="{{ $encargado->tipoAsistente['nombre'] }}"><i class="fa fa-heart"></i> {{ $encargado->tipoAsistente['nombre'] }}</label> 
                             @endif 
                             <b> {{ $encargado['id'] }} - </b> {{$encargado['nombre'].' '.$encargado['apellido'] }} <br>
                          @endforeach
                          @if(isset($grupo->linea()->nombre))<label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="" data-original-title="Linea">Linea</label> {{ $grupo->linea()->nombre }} @endif
                        </td>
                        <td>
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Total Integrantes"> <i class="fa fa-male"></i> <i class="fa fa-female"></i></label> 
                          {{ $reporte->asistentes->count() }} Personas<br>
                          <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="" data-original-title="Asistieron">Asistieron:</label> {{ $reporte->asistentes()->where('asistio', '=', '1')->count() }} <br>
                          <label class="label arrowed-right label-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="No asistieron">No asistieron:</label> {{ $reporte->asistentes()->where('asistio', '=', '0')->count() }} <br>
                        </td>                  
                        <td  class="oculta-celdas" style="width: 200px;" >
                           <p> <label class="label arrowed-right label-info" data-toggle="tooltip" data-placement="top" title="Observación"> <i class="fa fa-lightbulb-o"></i></label> {{  substr($reporte->observacion , 0, 100);  }}  @if (strlen($reporte->observacion) > 100) ... @endif</p><br>
                        </td>                            
                        <td>
                          <div class="btn-group">
                            <button type="button" class="btn btn-success btn-info dropdown-toggle" data-toggle="dropdown">
                                Opciones  
                                <i class="fa fa-caret-down"> </i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a href="../perfil/{{$reporte->id}}">Ver Informe</a></li>
                                <li><a href="../actualizar/{{ $reporte->id }}">Modificar</a></li>
                                @if(Auth::user()->id==1)
                                <li><a href="#">Eliminar</a></li>
                                @endif
                            </ul>
                          </div>
                        </td>
                      </tr>
                      @endforeach
                    </tbody>
                  </table>
                </div>
                <!-- /tabla -->
              </div> <!-- /panel body -->  
              <div class="box-footer">                                   
                <div class="row">                                        
                    <div class="col-lg-4">                                            
                      <h4> <b>{{ $reportes->getFrom() }}</b> - <b>{{ $reportes->getTo() }}</b> de <b>{{ $reportes->getTotal() }} </b> registros.</h4> 
                    </div>
                    @if(!isset($buscar))
                      <div class="col-lg-8 text-right" style="padding-right: 30px!important;"> {{ $reportes->links() }} </div>
                    @else
                      <div class="col-lg-8 text-right" style="padding-right: 30px!important;"> {{ $reportes->appends(array('buscar' => $buscar))->links() }}</div>
                    @endif
                </div>
              </div>          

            </div><!-- /Box primary -->

          </div><!-- /Div de 12 columnas -->
        </div><!-- /row -->
      </section>
      <!-- contenido principal -->
    </aside>  
    
    @include('includes.scripts')
      
    <!-- DATA TABES SCRIPT -->
    <script src="{{ Lang::get('general.url-datatables') }}" type="text/javascript"></script>
    <script src="/js/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
    <!-- page script -->
    <script type="text/javascript">

      $(document).ready(function() {

        $("#menu_grupos").attr('class', 'treeview active');
        $("#submenu_grupos").attr('style', 'display: block;');
        $("#flecha_grupos").attr('class', 'fa fa-angle-down pull-right');

				
       
			});
    </script>
  </body>
</html>

@endif